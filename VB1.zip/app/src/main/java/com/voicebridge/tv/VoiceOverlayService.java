package com.voicebridge.tv;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

public class VoiceOverlayService extends Service {
    public static final String ACTION_HANDLE =
            "com.vxm.voiceassist.action.HANDLE_MOBILE_RESULT";

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_HANDLE.equals(intent.getAction())) {
            String q = intent.getStringExtra("mobile_voice_result");
            if (q != null) {
                Log.i("VoiceBridge", "QUERY=" + q);
                boolean handled = CommandRouter.dispatch(this, q);
                Log.i("VoiceBridge", "HANDLED=" + handled);
            }
        }
        stopSelf(startId);
        return START_NOT_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
