package com.voicebridge.tv;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    public static final String TIZENTUBE_PACKAGE = "io.gh.reisxd.tizentube.cobalt";
    public static final String SMARTTUBE_PACKAGE = "com.teamsmart.videomanager.tv";

    private TextView adbStatus;
    private TextView voiceStatus;
    private TextView debug;
    private AdbBridge adb;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        adb = new AdbBridge(this);
        buildUi();
    }

    private TextView text(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(Color.DKGRAY);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(18);
        b.setAllCaps(false);
        b.setMinHeight(58);
        return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(40, 24, 40, 20);
        root.setBackgroundColor(Color.WHITE);

        root.addView(text("YouTube không quảng cáo", 28),
            new LinearLayout.LayoutParams(-1, 70));

        RadioGroup rg = new RadioGroup(this);
        rg.setOrientation(RadioGroup.VERTICAL);
        RadioButton tiz = new RadioButton(this);
        tiz.setText("Tizentube");
        tiz.setTextSize(22);
        tiz.setChecked(true);
        RadioButton smart = new RadioButton(this);
        smart.setText("SmartTube");
        smart.setTextSize(22);
        rg.addView(tiz);
        rg.addView(smart);
        root.addView(rg);

        LinearLayout status = new LinearLayout(this);
        status.setOrientation(LinearLayout.VERTICAL);
        adbStatus = text("ADB nội bộ: CHƯA KẾT NỐI", 20);
        voiceStatus = text("GIỌNG NÓI: CHƯA CẤP QUYỀN", 20);
        status.addView(adbStatus);
        status.addView(voiceStatus);
        root.addView(status, new LinearLayout.LayoutParams(-1, 95));

        Button voice = button("🎙️  CẤP QUYỀN GIỌNG NÓI");
        voice.setOnClickListener(v -> requestVoice());
        root.addView(voice);

        Button bridge = button("KÍCH HOẠT CẦU NỐI ADB");
        bridge.setOnClickListener(v -> startBridge());
        root.addView(bridge);

        Button test = button("▶  TEST: MỞ TÌM KIẾM");
        test.setOnClickListener(v -> openSearch(rg));
        root.addView(test);

        Button dbg = button("🔎 XEM DEBUG CẦU NỐI");
        dbg.setOnClickListener(v ->
            debug.setVisibility(debug.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        root.addView(dbg);

        debug = text("SCRIPT_LAUNCHED=0\nLISTENER_SCRIPT_INSTALLED=0\nFIX11_READY=5555\n", 15);
        debug.setGravity(Gravity.LEFT | Gravity.TOP);
        debug.setPadding(0, 12, 0, 0);
        debug.setVisibility(View.GONE);
        root.addView(debug, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
        updatePermissionState();
    }

    private void requestVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 10);
        } else {
            updatePermissionState();
        }
    }

    private void updatePermissionState() {
        voiceStatus.setText(
            checkSelfPermission(Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED
            ? "GIỌNG NÓI: ĐÃ CẤP QUYỀN ✓"
            : "GIỌNG NÓI: CHƯA CẤP QUYỀN");
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        updatePermissionState();
    }

    private void startBridge() {
        startService(new Intent(this, SelfAdbService.class));
        startService(new Intent(this, GuardianService.class));
        adb.connect(new AdbBridge.Listener() {
            public void onState(String s) {
                runOnUiThread(() -> adbStatus.setText(s));
            }
            public void onLine(String s) {
                runOnUiThread(() -> debug.append("\n" + s));
            }
        });
    }

    private void openSearch(RadioGroup rg) {
        int id = rg.getCheckedRadioButtonId();
        RadioButton rb = findViewById(id);
        boolean smart = rb != null && rb.getText().toString().contains("SmartTube");
        String q = smart ? "mở SmartTube tìm kiếm" : "mở TizenTube tìm kiếm";
        Intent i = new Intent(this, VoiceOverlayService.class);
        i.setAction(VoiceOverlayService.ACTION_HANDLE);
        i.putExtra("mobile_voice_result", q);
        startService(i);
        Toast.makeText(this, "Đã gửi lệnh test", Toast.LENGTH_SHORT).show();
    }
}
