package com.voicebridge.tv;

import android.service.voice.VoiceInteractionService;

public class VoiceInteractionServiceImpl extends VoiceInteractionService {
    @Override public void onReady() {
        super.onReady();
    }
}
