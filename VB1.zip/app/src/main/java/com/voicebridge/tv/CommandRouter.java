package com.voicebridge.tv;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

import java.util.Locale;

/**
 * Small deterministic router for the two TV players.
 * It intentionally avoids undocumented/private player APIs.
 */
public final class CommandRouter {
    private static final String TAG = "VoiceBridgeRouter";
    private static final String TIZEN = "io.gh.reisxd.tizentube.cobalt";
    private static final String SMART = "com.teamsmart.videomanager.tv";

    private CommandRouter() {}

    public static boolean dispatch(Context context, String raw) {
        if (raw == null) return false;
        String q = raw.trim();
        String n = q.toLowerCase(Locale.ROOT);

        if (n.contains("smarttube") || n.contains("smart tube")) {
            return launchSearch(context, SMART, extractSearch(q));
        }
        if (n.contains("tizentube") || n.contains("tizen tube")) {
            return launchSearch(context, TIZEN, extractSearch(q));
        }

        // Default to TizenTube when a YouTube/search request is spoken.
        if (n.contains("youtube") || n.contains("tìm ") || n.startsWith("tìm")
                || n.contains("search") || n.contains("mở video")) {
            return launchSearch(context, TIZEN, extractSearch(q));
        }

        return false;
    }

    private static String extractSearch(String q) {
        String n = q.toLowerCase(Locale.ROOT);
        String[] markers = {"youtube", "smarttube", "smart tube", "tizentube",
                "tizen tube", "tìm kiếm", "tìm", "search"};
        for (String marker : markers) {
            int i = n.indexOf(marker);
            if (i >= 0) {
                String s = q.substring(i + marker.length()).trim();
                s = s.replaceFirst("^[\\s:,-]+", "");
                if (!s.isEmpty()) return s;
            }
        }
        return q;
    }

    private static boolean launchSearch(Context c, String pkg, String query) {
        Intent launch = c.getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) {
            Log.w(TAG, "Package not installed: " + pkg);
            return false;
        }

        // Generic ACTION_VIEW is the safest public contract. The player decides
        // whether it can consume the query URI.
        if (query != null && !query.isEmpty()) {
            Intent view = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query="
                            + Uri.encode(query)));
            view.setPackage(pkg);
            view.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                c.startActivity(view);
                return true;
            } catch (Exception ignored) {}
        }

        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(launch);
        return true;
    }
}
