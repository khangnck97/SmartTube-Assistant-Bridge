package com.voicebridge.tv;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Self-ADB coordinator modeled from the supplied VietMITV APK:
 * local ADB -> RSA auth -> shell -> listener/watchdog.
 *
 * The Android system/adbd owns the RSA authorization dialog.
 */
public class SelfAdbService extends Service {
    public static final String TAG = "VxmSelfAdb";
    private ExecutorService executor;
    private AdbBridge adb;

    @Override public void onCreate() {
        super.onCreate();
        executor = Executors.newSingleThreadExecutor();
        adb = new AdbBridge(this);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        executor.execute(() -> adb.connect(new AdbBridge.Listener() {
            @Override public void onState(String state) {
                Log.i(TAG, state);
            }
            @Override public void onLine(String line) {
                Log.i(TAG, line);
            }
        }));
        return START_STICKY;
    }

    @Override public void onDestroy() {
        if (executor != null) executor.shutdownNow();
        if (adb != null) adb.close();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
