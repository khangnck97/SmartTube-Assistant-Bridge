package com.voicebridge.tv;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/** Lightweight watchdog corresponding to the Guardian/self-heal concept in VietMITV. */
public class GuardianService extends Service {
    private ScheduledExecutorService scheduler;

    @Override public void onCreate() {
        super.onCreate();
        scheduler = Executors.newSingleThreadScheduledExecutor();
        scheduler.scheduleAtFixedRate(() ->
            startService(new Intent(this, SelfAdbService.class)),
            0, 60, TimeUnit.SECONDS);
    }

    @Override public void onDestroy() {
        if (scheduler != null) scheduler.shutdownNow();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
