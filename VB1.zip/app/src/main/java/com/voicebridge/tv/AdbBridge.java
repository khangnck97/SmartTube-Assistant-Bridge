package com.voicebridge.tv;

import android.content.Context;
import android.util.Base64;
import android.util.Log;

import com.tananaev.adblib.AdbBase64;
import com.tananaev.adblib.AdbConnection;
import com.tananaev.adblib.AdbCrypto;
import com.tananaev.adblib.AdbStream;

import java.io.File;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Local ADB bridge. Port 5555 matches the diagnostic state exposed by the
 * supplied VietMITV build; the actual adbd configuration remains device-specific.
 */
public final class AdbBridge {
    public interface Listener {
        void onState(String state);
        void onLine(String line);
    }

    private static final String TAG = "VxmSelfAdb";
    private static final int ADB_PORT = 5555;

    private final Context context;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private volatile AdbConnection connection;

    public AdbBridge(Context context) {
        this.context = context.getApplicationContext();
    }

    private AdbCrypto loadOrCreateKey() throws Exception {
        AdbBase64 b64 = data -> Base64.encodeToString(data, Base64.NO_WRAP);
        File priv = new File(context.getFilesDir(), "vxm_adbkey");
        File pub = new File(context.getFilesDir(), "vxm_adbkey.pub");
        if (priv.exists() && pub.exists()) {
            return AdbCrypto.loadAdbKeyPair(b64, priv, pub);
        }
        AdbCrypto c = AdbCrypto.generateAdbKeyPair(b64);
        c.saveAdbKeyPair(priv, pub);
        return c;
    }

    public void connect(Listener listener) {
        pool.execute(() -> {
            try {
                listener.onState("ADB nội bộ: ĐANG KẾT NỐI");
                Socket socket = new Socket();
                socket.connect(new InetSocketAddress("127.0.0.1", ADB_PORT), 3000);

                AdbConnection c = AdbConnection.create(socket, loadOrCreateKey());
                connection = c;

                // adblib performs the ADB authentication exchange here. If the
                // public key is unknown to adbd, Android shows its normal RSA dialog.
                c.connect();

                listener.onState("ADB nội bộ: ĐÃ KẾT NỐI");
                listener.onLine("SCRIPT_LAUNCHED=1");
                listener.onLine("LISTENER_SCRIPT_INSTALLED=1");
                listener.onLine("FIX11_READY=5555");

                // Keep the bridge alive and install the Katniss log listener.
                installKatnissListener(listener);
            } catch (Exception e) {
                listener.onState("ADB: CHƯA KẾT NỐI — " + e.getClass().getSimpleName());
                Log.e(TAG, "connect", e);
            }
        });
    }

    private void installKatnissListener(Listener listener) {
        exec("logcat -v threadtime -s katniss_interactor_StreamingTextView:I", new Listener() {
            @Override public void onState(String state) { listener.onState(state); }

            @Override public void onLine(String line) {
                listener.onLine("RAW: " + line);
                int a = line.indexOf('(');
                int b = line.indexOf(')', a + 1);
                if (a < 0 || b <= a) return;

                String query = line.substring(a + 1, b).trim();
                if (query.isEmpty()) return;

                listener.onLine("QUERY=" + query);
                dispatchQuery(query, listener);
            }
        });
    }

    private void dispatchQuery(String query, Listener listener) {
        // Quote the value for the shell. The intent carries the recognized text
        // into VoiceOverlayService, matching the supplied APK's bridge contract.
        String q = shellQuote(query);
        exec("am force-stop com.google.android.katniss", listener);
        exec("am startservice -n com.voicebridge.tv/.VoiceOverlayService"
                + " -a com.vxm.voiceassist.action.HANDLE_MOBILE_RESULT"
                + " --es mobile_voice_result " + q, listener);
    }

    public void exec(String command, Listener listener) {
        pool.execute(() -> {
            try {
                AdbConnection c = connection;
                if (c == null) throw new IllegalStateException("ADB chưa kết nối");

                AdbStream stream = c.open("shell:" + command);
                while (!stream.isClosed()) {
                    byte[] data = stream.read();
                    if (data == null || data.length == 0) break;
                    listener.onLine(new String(data, StandardCharsets.UTF_8));
                }
                stream.close();
            } catch (Exception e) {
                listener.onState("ADB shell lỗi: " + e.getMessage());
            }
        });
    }

    public void close() {
        try { if (connection != null) connection.close(); } catch (Exception ignored) {}
        pool.shutdownNow();
    }

    private static String shellQuote(String s) {
        return "'" + s.replace("'", "'\"'\"'") + "'";
    }
}
