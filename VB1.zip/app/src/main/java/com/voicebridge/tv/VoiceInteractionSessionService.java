package com.voicebridge.tv;

import android.service.voice.VoiceInteractionSession;

public class VoiceInteractionSessionService extends android.service.voice.VoiceInteractionSessionService {
    @Override public VoiceInteractionSession onNewSession(android.os.Bundle args) {
        return new VoiceSession(this);
    }
}

class VoiceSession extends VoiceInteractionSession {
    VoiceSession(android.content.Context c) { super(c); }
}
