package com.voicebridge.tv;

import android.service.voice.VoiceInteractionSession;
import android.service.voice.VoiceInteractionSessionService;

public class VoiceInteractionSessionService extends VoiceInteractionSessionService {
    @Override public VoiceInteractionSession onNewSession(android.os.Bundle args) {
        return new VoiceSession(this);
    }
}

class VoiceSession extends VoiceInteractionSession {
    VoiceSession(android.content.Context c) { super(c); }
}
