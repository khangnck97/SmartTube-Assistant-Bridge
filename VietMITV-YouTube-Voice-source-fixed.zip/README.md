# YouTube Voice

Bản dựng lại tối giản từ VietMITV, chỉ giữ chức năng nhận lệnh giọng nói để tìm kiếm YouTube và bỏ phần kênh truyền hình/M3U.

## Ứng dụng đích

- Tizentube: `io.gh.reisxd.tizentube.cobalt`
- SmartTube: `com.teamsmart.videomanager.tv`

## Build không cần PC

1. Tạo repository GitHub mới.
2. Upload toàn bộ nội dung ZIP này lên nhánh `main`.
3. Mở tab **Actions**.
4. Chọn **Build APK**.
5. Bấm **Run workflow**.
6. Khi chạy xong, vào phần **Artifacts** và tải `YouTube-Voice-debug`.

## Lưu ý

Đây là bản viết lại độc lập, không chứa code/asset được trích xuất từ APK gốc. Intent tìm kiếm sử dụng URL YouTube và cố định package ứng dụng được chọn. Nếu phiên bản Tizentube/SmartTube trên TV dùng Intent riêng, có thể cần điều chỉnh phần `openYoutubeSearch()`.
