package com.vietmitv.youtubevoice

import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.IBinder
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

class VoiceOverlayService : Service() {
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate() {
        super.onCreate()
        startListening()
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)

        recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                startListening()
            }

            override fun onResults(results: android.os.Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    ?: return
                handleVoiceCommand(text)
            }

            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer?.startListening(intent)
    }

    private fun handleVoiceCommand(command: String) {
        val normalized = command.trim()
        if (normalized.isEmpty()) {
            startListening()
            return
        }

        // Accept natural Vietnamese commands such as:
        // "mở Sơn Tùng", "tìm nhạc Sơn Tùng", "YouTube Sơn Tùng".
        val query = normalized
            .replace(Regex("(?i)^\\s*(mở|mo|tìm|tim|search|youtube)\\s*"), "")
            .trim()

        if (query.isNotEmpty()) {
            openYoutubeSearch(query)
        } else {
            openYoutubeSearch(normalized)
        }
    }

    private fun openYoutubeSearch(query: String) {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val selected = prefs.getString(
            "youtube_package",
            "io.gh.reisxd.tizentube.cobalt"
        ) ?: "io.gh.reisxd.tizentube.cobalt"

        val installed = try {
            packageManager.getApplicationInfo(selected, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }

        val encoded = Uri.encode(query)
        val url = "https://www.youtube.com/results?search_query=$encoded"

        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            if (installed) setPackage(selected)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        try {
            startActivity(intent)
        } catch (_: Exception) {
            // Fallback: let Android resolve the URL if the selected app cannot handle it.
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            )
        }

        startListening()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
