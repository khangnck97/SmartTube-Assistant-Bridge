package com.vietmitv.youtubevoice

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class MainActivity : androidx.appcompat.app.AppCompatActivity() {
    private lateinit var radioTizen: RadioButton
    private lateinit var radioSmart: RadioButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 32, 48, 32)
        }

        val title = TextView(this).apply {
            text = "YouTube không quảng cáo"
            textSize = 26f
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val group = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            setPadding(0, 32, 0, 24)
        }

        radioTizen = RadioButton(this).apply {
            text = "Tizentube"
            textSize = 20f
            tag = "io.gh.reisxd.tizentube.cobalt"
        }
        radioSmart = RadioButton(this).apply {
            text = "SmartTube"
            textSize = 20f
            tag = "com.teamsmart.videomanager.tv"
        }
        group.addView(radioTizen)
        group.addView(radioSmart)

        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val saved = prefs.getString("youtube_package", "")
        if (saved == radioSmart.tag) radioSmart.isChecked = true
        else radioTizen.isChecked = true

        group.setOnCheckedChangeListener { _, id ->
            val selected = findViewById<RadioButton>(id)
            prefs.edit().putString("youtube_package", selected.tag.toString()).apply()
        }

        val start = Button(this).apply {
            text = "Bật trợ lý giọng nói"
            textSize = 18f
            setOnClickListener {
                if (android.os.Build.VERSION.SDK_INT >= 23 &&
                    checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
                } else {
                    startService(Intent(this@MainActivity, VoiceOverlayService::class.java))
                    Toast.makeText(this@MainActivity, "Đã bật nhận lệnh giọng nói", Toast.LENGTH_SHORT).show()
                }
            }
        }
        root.addView(group, LinearLayout.LayoutParams(-1, -2))
        root.addView(start, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 100 && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) {
            startService(Intent(this, VoiceOverlayService::class.java))
        }
    }
}
