# VietMITV YouTube Voice – ADB Role Bridge FIX11

FIX11 sửa lỗi biên dịch Kotlin do các biến shell `$DEBUG`, `$PIDFILE`, `$line`, `$query`, `$!` bị Kotlin hiểu nhầm. Script shell được dựng bằng placeholder và escape dollar đúng cách.

Listener dùng `logcat -b all` và lọc `katniss_interactor_StreamingTextView`, sau đó gửi query sang VoiceOverlayService.
\nFIX14: "Mở video" / "mo video" now launches the selected player only; it no longer constructs a YouTube search URL. Search is only triggered by explicit search phrases such as "tìm ...", "tìm kiếm ...", "search ...", or "YouTube ...".\n