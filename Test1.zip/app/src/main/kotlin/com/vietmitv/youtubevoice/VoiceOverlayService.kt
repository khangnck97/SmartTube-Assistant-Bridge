package com.vietmitv.youtubevoice

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import java.util.Locale

class VoiceOverlayService : Service() {

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(
            77,
            Notification.Builder(this, "voice")
                .setContentTitle("YouTube Voice")
                .setContentText("Đang chờ Google Assistant")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_ASSISTANT_RESULT) {
            val query = intent.getStringExtra("assistant_query").orEmpty().trim()
            if (query.isNotEmpty()) {
                handleAssistantCommand(query)
            }
        }
        return START_STICKY
    }

    private fun handleAssistantCommand(raw: String) {
        val normalized = raw.trim()
            .lowercase(Locale.ROOT)
            .replace(Regex("\\s+"), " ")

        // "Mở video" is a launch-only command. Do NOT turn it into a
        // YouTube search for the literal words "video".
        if (normalized == "mở video" || normalized == "mo video") {
            launchSelectedPlayer()
            return
        }

        // Search is reserved for explicit search language.
        if (normalized.startsWith("tìm kiếm ") ||
            normalized.startsWith("tim kiem ") ||
            normalized.startsWith("tìm ") ||
            normalized.startsWith("tim ") ||
            normalized.startsWith("search ")) {

            val query = normalized
                .replaceFirst(Regex("^(mở|mo)\\s+"), "")
                .replaceFirst(Regex("^(tìm kiếm|tim kiem|tìm|tim|search)\\s*"), "")
                .trim()

            if (query.isNotEmpty()) {
                openYoutubeSearch(query)
                return
            }
        }

        // Keep ordinary "mở video" semantics launch-only. For other commands,
        // preserve the existing behavior of opening the selected player.
        if (normalized == "mở" || normalized == "mo" || normalized == "mở youtube" || normalized == "mo youtube") {
            launchSelectedPlayer()
            return
        }

        // An explicit YouTube phrase with content remains a search.
        val youtubeQuery = normalized
            .replaceFirst(Regex("^(youtube)\\s*"), "")
            .trim()
        if (normalized.startsWith("youtube ") && youtubeQuery.isNotEmpty()) {
            openYoutubeSearch(youtubeQuery)
            return
        }

        launchSelectedPlayer()
    }

    private fun selectedPackage(): String {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        return prefs.getString(
            "youtube_package",
            "io.gh.reisxd.tizentube.cobalt"
        ) ?: "io.gh.reisxd.tizentube.cobalt"
    }

    private fun launchSelectedPlayer() {
        val selected = selectedPackage()
        try {
            val launch = packageManager.getLaunchIntentForPackage(selected)
                ?: throw IllegalStateException("Package not installed: $selected")
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launch)
        } catch (_: Exception) {
            // No search fallback here: "mở video" must never trigger a search.
        }
    }

    private fun openYoutubeSearch(query: String) {
        val selected = selectedPackage()
        val installed = try {
            packageManager.getApplicationInfo(selected, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }

        val url = "https://www.youtube.com/results?search_query=${Uri.encode(query)}"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (installed) setPackage(selected)
        }

        try {
            startActivity(intent)
        } catch (_: Exception) {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            )
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(
                    NotificationChannel(
                        "voice",
                        "Google Assistant bridge",
                        NotificationManager.IMPORTANCE_LOW
                    )
                )
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_ASSISTANT_RESULT =
            "com.vietmitv.youtubevoice.action.HANDLE_ASSISTANT_RESULT"

        fun openSearchFromActivity(context: Context, query: String) {
            val i = Intent(context, VoiceOverlayService::class.java).apply {
                action = ACTION_ASSISTANT_RESULT
                putExtra("assistant_query", query)
            }
            context.startForegroundService(i)
        }
    }
}
