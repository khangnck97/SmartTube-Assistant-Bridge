package com.vietmitv.youtubevoice

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors
import java.util.regex.Pattern

class VoiceOverlayService : Service() {
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(77, Notification.Builder(this, "voice")
            .setContentTitle("YouTube Voice")
            .setContentText("Đang chờ Google Assistant")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_ASSISTANT_RESULT) {
            val query = intent.getStringExtra("assistant_query").orEmpty().trim()
            if (query.isNotEmpty()) handleAssistantCommand(query)
        }
        return START_STICKY
    }

    private fun handleAssistantCommand(raw: String) {
        val query = raw.replace(
            Regex("(?i)^\\s*(mở|mo|mở|mở video|mo video|tìm|tim|tìm kiếm|tim kiem|search|youtube)\\s*"), ""
        ).trim().ifBlank { raw.trim() }

        // "mở ..." should try to resolve the first YouTube video, not merely
        // open a search-results page. If resolution fails, fall back to search.
        executor.execute {
            val videoUrl = resolveFirstYoutubeVideo(query)
            Handler(Looper.getMainLooper()).post {
                if (videoUrl != null) openYoutubeUrl(videoUrl) else openYoutubeSearch(query)
            }
        }
    }

    private fun resolveFirstYoutubeVideo(query: String): String? {
        return try {
            val encoded = URLEncoder.encode(query.trim(), "UTF-8")
            val url = URL("https://www.youtube.com/results?search_query=$encoded")
            val c = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 5000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android TV 14) AppleWebKit/537.36 Chrome/120 Safari/537.36")
                setRequestProperty("Accept-Language", "vi-VN,vi;q=0.9,en;q=0.7")
            }
            val body = c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            c.disconnect()
            val p = Pattern.compile("""videoId\\?["']?\\s*[:=]\\s*["']([A-Za-z0-9_-]{11})["']""")
            val m = p.matcher(body)
            if (m.find()) "https://www.youtube.com/watch?v=${m.group(1)}" else null
        } catch (_: Exception) { null }
    }

    private fun openYoutubeUrl(url: String) {
        val selected = selectedPackage()
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (selected != null) setPackage(selected)
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        }
    }

    private fun openYoutubeSearch(query: String) {
        val url = "https://www.youtube.com/results?search_query=${Uri.encode(query)}"
        val selected = selectedPackage()
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (selected != null) setPackage(selected)
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        }
    }

    private fun selectedPackage(): String? {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val selected = prefs.getString("youtube_package", "io.gh.reisxd.tizentube.cobalt")
            ?: "io.gh.reisxd.tizentube.cobalt"
        return try {
            packageManager.getApplicationInfo(selected, 0)
            selected
        } catch (_: PackageManager.NameNotFoundException) {
            null
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel("voice", "Google Assistant bridge", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_ASSISTANT_RESULT = "com.vietmitv.youtubevoice.action.HANDLE_ASSISTANT_RESULT"

        fun openSearchFromActivity(context: Context, query: String) {
            val i = Intent(context, VoiceOverlayService::class.java).apply {
                action = ACTION_ASSISTANT_RESULT
                putExtra("assistant_query", query)
            }
            context.startForegroundService(i)
        }
    }
}
