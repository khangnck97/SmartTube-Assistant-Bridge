# VietMITV YouTube Voice – ADB Role Bridge FIX11

FIX11 sửa lỗi biên dịch Kotlin do các biến shell `$DEBUG`, `$PIDFILE`, `$line`, `$query`, `$!` bị Kotlin hiểu nhầm. Script shell được dựng bằng placeholder và escape dollar đúng cách.

Listener dùng `logcat -b all` và lọc `katniss_interactor_StreamingTextView`, sau đó gửi query sang VoiceOverlayService.


## DIRECT ADB bridge
The listener captures `katniss_interactor_StreamingTextView`, stops Katniss, and launches the selected YouTube client directly with `am start`. It no longer calls `am startservice` on `VoiceOverlayService`, avoiding the previous `Failed transaction (2147483646)` path.
