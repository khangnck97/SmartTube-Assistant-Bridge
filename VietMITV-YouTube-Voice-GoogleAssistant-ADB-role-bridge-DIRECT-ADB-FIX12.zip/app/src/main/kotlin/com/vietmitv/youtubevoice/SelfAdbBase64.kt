package com.vietmitv.youtubevoice

import com.tananaev.adblib.AdbBase64
import java.util.Base64

/** Same small Base64 adapter used by the VietMITV self-ADB implementation. */
object SelfAdbBase64 : AdbBase64 {
    override fun encodeToString(data: ByteArray): String =
        Base64.getEncoder().encodeToString(data)
}
