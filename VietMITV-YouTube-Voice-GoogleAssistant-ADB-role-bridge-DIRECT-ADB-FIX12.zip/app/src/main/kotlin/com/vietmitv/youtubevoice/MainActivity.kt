package com.vietmitv.youtubevoice

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import java.io.File
import androidx.core.content.ContextCompat
import androidx.core.app.ActivityCompat

class MainActivity : androidx.appcompat.app.AppCompatActivity() {
    private val microphonePermissionRequestCode = 1001
    private lateinit var radioTizen: RadioButton
    private lateinit var radioSmart: RadioButton
    private lateinit var status: TextView
    private lateinit var debug: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 32, 48, 32)
        }

        root.addView(TextView(this).apply {
            text = "YouTube không quảng cáo"
            textSize = 26f
            gravity = Gravity.CENTER
        })

        val group = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            setPadding(0, 24, 0, 12)
        }
        radioTizen = RadioButton(this).apply {
            text = "Tizentube"
            textSize = 20f
            tag = "io.gh.reisxd.tizentube.cobalt"
        }
        radioSmart = RadioButton(this).apply {
            text = "SmartTube"
            textSize = 20f
            tag = "com.teamsmart.videomanager.tv"
        }
        group.addView(radioTizen)
        group.addView(radioSmart)

        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        if (prefs.getString("youtube_package", "") == radioSmart.tag) {
            radioSmart.isChecked = true
        } else {
            radioTizen.isChecked = true
        }

        group.setOnCheckedChangeListener { _, id ->
            val selected = findViewById<RadioButton>(id)
            prefs.edit().putString("youtube_package", selected.tag.toString()).apply()
        }
        root.addView(group)

        status = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            text = adbStatus()
        }
        root.addView(status)

        val voiceStatus = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
            text = microphoneStatus()
        }
        root.addView(voiceStatus)

        val voicePermission = Button(this).apply {
            text = "🎙 CẤP QUYỀN GIỌNG NÓI"
            textSize = 18f
            setOnClickListener {
                requestMicrophonePermission()
                root.postDelayed({ voiceStatus.text = microphoneStatus() }, 1000L)
            }
        }
        root.addView(voicePermission)

        val adb = Button(this).apply {
            text = "KÍCH HOẠT CẦU NỐI ADB"
            textSize = 18f
            setOnClickListener {
                ContextCompat.startForegroundService(
                    this@MainActivity,
                    Intent(this@MainActivity, SelfAdbService::class.java)
                )
                Toast.makeText(
                    this@MainActivity,
                    "Đang yêu cầu quyền ADB… Hãy chờ hộp thoại Cho phép gỡ lỗi USB/ADB và bấm Cho phép.",
                    Toast.LENGTH_LONG
                ).show()
                root.postDelayed({ status.text = adbStatus() }, 35000)
            }
        }
        root.addView(adb)

        val test = Button(this).apply {
            text = "▶ TEST: MỞ TÌM KIẾM"
            textSize = 18f
            setOnClickListener {
                VoiceOverlayService.openSearchFromActivity(
                    this@MainActivity,
                    "YouTube"
                )
            }
        }
        root.addView(test)

        val debugButton = Button(this).apply {
            text = "🔎 XEM DEBUG CẦU NỐI"
            textSize = 18f
            setOnClickListener { debug.text = readDebug() }
        }
        root.addView(debugButton)

        debug = TextView(this).apply {
            textSize = 13f
            setPadding(0, 16, 0, 0)
            text = "Chưa có log debug."
        }
        root.addView(debug)

        setContentView(root)

        root.postDelayed(object : Runnable {
            override fun run() {
                status.text = adbStatus()
                voiceStatus.text = microphoneStatus()
                if (::debug.isInitialized) debug.text = readDebug()
                root.postDelayed(this, 3000L)
            }
        }, 3000L)
    }

    private fun requestMicrophonePermission() {
        if (android.os.Build.VERSION.SDK_INT < 23) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Quyền giọng nói đã được cấp.", Toast.LENGTH_SHORT).show()
            return
        }
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.RECORD_AUDIO),
            microphonePermissionRequestCode
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == microphonePermissionRequestCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Đã cấp quyền giọng nói ✓", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Chưa được cấp quyền giọng nói. Hãy cho phép Microphone.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun microphoneStatus(): String {
        return if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            "GIỌNG NÓI: ĐÃ CẤP QUYỀN ✓"
        } else {
            "GIỌNG NÓI: CHƯA CẤP QUYỀN"
        }
    }

    private fun readDebug(): String {
        return try {
            val file = File(getExternalFilesDir(null), "assistant_bridge.log")
            if (!file.exists()) return "Chưa có log debug. Hãy bấm KÍCH HOẠT CẦU NỐI ADB."
            val lines = file.readLines()
            lines.takeLast(30).joinToString("\n").ifBlank { "Log trống." }
        } catch (e: Exception) {
            "Không đọc được debug: ${e.message}"
        }
    }

    private fun adbStatus(): String {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        return if (prefs.getBoolean("adb_ready", false)) {
            "ADB nội bộ: ĐÃ KẾT NỐI"
        } else {
            "ADB nội bộ: đang chờ cấp quyền / kết nối"
        }
    }
}
