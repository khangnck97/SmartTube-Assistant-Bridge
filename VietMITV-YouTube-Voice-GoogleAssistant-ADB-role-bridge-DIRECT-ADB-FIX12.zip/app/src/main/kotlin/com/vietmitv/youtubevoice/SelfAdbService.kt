package com.vietmitv.youtubevoice

import android.app.*
import android.content.Intent
import android.os.*
import java.util.concurrent.Executors

/** VietMITV-style persistent self-ADB service. */
class SelfAdbService : Service() {
    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = true
    @Volatile private var ready = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(78, Notification.Builder(this, "adb")
            .setContentTitle("YouTube Voice")
            .setContentText("Đang duy trì cầu nối ADB…")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .build())
        KeepAliveReceiver.schedule(this)
        checkAdbAuthorization(0L)
    }

    private fun checkAdbAuthorization(delay: Long) {
        handler.postDelayed({
            if (!running) return@postDelayed
            executor.execute {
                val ok = SelfAdbWorker(this).runOnce {
                    getSharedPreferences("settings", MODE_PRIVATE).edit()
                        .putBoolean("adb_ready", true)
                        .putLong("adb_authorized_at", System.currentTimeMillis())
                        .apply()
                    ready = true
                }
                if (!ok) {
                    ready = false
                    getSharedPreferences("settings", MODE_PRIVATE).edit()
                        .putBoolean("adb_ready", false)
                        .putLong("adb_last_check", System.currentTimeMillis())
                        .apply()
                }
                // Retry like the original self-healing worker.
                checkAdbAuthorization(if (ok) 30_000L else 5_000L)
            }
        }, delay)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(
                    NotificationChannel("adb", "ADB bridge", NotificationManager.IMPORTANCE_LOW)
                )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        executor.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
