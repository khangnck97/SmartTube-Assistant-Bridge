package com.vietmitv.youtubevoice

import android.content.Context
import android.util.Base64
import com.tananaev.adblib.AdbConnection
import com.tananaev.adblib.AdbCrypto
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/** DIRECT BRIDGE: ADB config + persistent Katniss listener that launches YouTube directly. */
class SelfAdbWorker(private val context: Context) {
    private val ports = intArrayOf(5555, 5556, 5557, 5558)
    private val packageName = context.packageName
    private val localLog = File(context.getExternalFilesDir(null), "assistant_bridge.log")

    fun runOnce(onAuthorized: () -> Unit): Boolean {
        localDebug("=== VietMITV Assistant Bridge FIX11 started ===")
        localDebug("time=" + SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date()))
        val crypto = try { loadOrCreateCrypto() } catch (e: Exception) {
            localDebug("KEY_ERROR: ${e.javaClass.simpleName}: ${e.message}")
            return false
        }

        for (port in ports) {
            localDebug("TRY_PORT=$port")
            var socket: Socket? = null
            var connection: AdbConnection? = null
            try {
                socket = Socket().apply {
                    tcpNoDelay = true
                    keepAlive = true
                    connect(InetSocketAddress("127.0.0.1", port), 2500)
                }
                localDebug("ADB_SOCKET_CONNECTED=$port")
                connection = AdbConnection.create(socket, crypto)
                if (!connection.connect(90, TimeUnit.SECONDS, false)) {
                    localDebug("ADB_CONNECT_FALSE=$port")
                    try { connection.close() } catch (_: Exception) {}
                    try { socket.close() } catch (_: Exception) {}
                    continue
                }
                localDebug("ADB_AUTHORIZED=$port")
                onAuthorized()
                prepare(connection)
                if (!installAndLaunchListener(connection)) {
                    localDebug("LISTENER_LAUNCH_FAILED=$port")
                    try { connection.close() } catch (_: Exception) {}
                    try { socket.close() } catch (_: Exception) {}
                    return false
                }
                localDebug("FIX11_READY=$port")
                try { connection.close() } catch (_: Exception) {}
                try { socket.close() } catch (_: Exception) {}
                return true
            } catch (e: Exception) {
                localDebug("ERROR: ${e.javaClass.simpleName}: ${e.message}")
                try { connection?.close() } catch (_: Exception) {}
                try { socket?.close() } catch (_: Exception) {}
            }
        }
        localDebug("NO_ADB_PORT_CONNECTED")
        return false
    }

    private fun prepare(connection: AdbConnection) {
        localDebug("PREPARE_START")
        shell(connection, "pm enable --user 0 com.google.android.katniss")
        shell(connection, "cmd role remove-role-holder android.app.role.ASSISTANT $packageName 0")
        shell(connection, "cmd role add-role-holder android.app.role.ASSISTANT com.google.android.katniss 0")
        shell(connection, "pm grant $packageName android.permission.WRITE_SECURE_SETTINGS")
        shell(connection, "appops set $packageName SYSTEM_ALERT_WINDOW allow")
        shell(connection, "sh -c 'nohup sh -c \"while true; do appops set $packageName SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; sleep 60; done\" </dev/null >/dev/null 2>&1 &'")
        localDebug("PREPARE_DONE")
    }

    private fun installAndLaunchListener(connection: AdbConnection): Boolean {
        // DIRECT ADB BRIDGE:
        // Google/Katniss remains the ASSISTANT role. We capture the recognized
        // text from Katniss, stop Katniss, then launch the selected YouTube
        // client directly with `am start`. This avoids starting our own
        // foreground service from the shell (which can fail with Android's
        // background/FGS restrictions).
        val debugPath = "/sdcard/Android/data/$packageName/files/assistant_bridge.log"
        val selected = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
            .getString("youtube_package", "io.gh.reisxd.tizentube.cobalt")
            ?: "io.gh.reisxd.tizentube.cobalt"

        val targetPackage = if (selected == "com.teamsmart.videomanager.tv") {
            "com.teamsmart.videomanager.tv"
        } else {
            "io.gh.reisxd.tizentube.cobalt"
        }

        val scriptTemplate = """
#!/system/bin/sh
DEBUG='__DEBUG_PATH__'
PIDFILE=/data/local/tmp/vietmitv_assistant_bridge.pid
TARGET_PACKAGE='__TARGET_PACKAGE__'

mkdir -p "${'$'}(dirname "${'$'}DEBUG")"
log_line() { printf '%s\n' "${'$'}*" >> "${'$'}DEBUG"; }

if [ -f "${'$'}PIDFILE" ]; then
  oldpid=${'$'}(cat "${'$'}PIDFILE" 2>/dev/null)
  [ -n "${'$'}oldpid" ] && kill "${'$'}oldpid" 2>/dev/null || true
fi
rm -f "${'$'}PIDFILE"

log_line '=== VietMITV Assistant Bridge DIRECT ADB ==='
log_line "time=${'$'}(date '+%Y-%m-%d %H:%M:%S')"
log_line "assistant=${'$'}(settings get secure assistant 2>&1)"
log_line "voice_service=${'$'}(settings get secure voice_interaction_service 2>&1)"
log_line "katniss=${'$'}(pm path com.google.android.katniss 2>&1)"
log_line "TARGET_PACKAGE=${'$'}TARGET_PACKAGE"
log_line 'LISTENER_MODE=DIRECT_AM_START'
log_line 'LISTENER_START=1'

(
  echo ${'$'}${'$'} > "${'$'}PIDFILE"

  logcat -c >/dev/null 2>&1
  log_line 'LOGCAT_CLEARED=1'

  logcat -v threadtime -s katniss_interactor_StreamingTextView:I 2>&1 |
    while IFS= read -r line; do
      log_line "RAW: ${'$'}line"

      query=${'$'}(printf '%s\n' "${'$'}line" | awk -F'[()]' '{print ${'$'}2}')
      query=${'$'}(printf '%s' "${'$'}query" | sed 's/^[[:space:]]*//; s/[[:space:]]*${'$'}//')

      if [ -n "${'$'}query" ] && ! printf '%s' "${'$'}query" | grep -Eq '^[0-9]+${'$'}'; then
        log_line "QUERY=${'$'}query"

        # Stop Google's Katniss UI before handing the query to the
        # selected YouTube client.
        am force-stop com.google.android.katniss >/dev/null 2>&1
        log_line 'KATNISS_STOPPED=1'

        # No am startservice here. Launch the selected YouTube app directly.
        # The query is kept as one shell argument so spaces and Vietnamese
        # characters survive the ADB shell boundary.
        am start -a android.intent.action.VIEW \
          -d "https://www.youtube.com/results?search_query=${'$'}query" \
          -p "${'$'}TARGET_PACKAGE" >> "${'$'}DEBUG" 2>&1

        result=${'$'}?
        log_line "AM_START_RESULT=${'$'}result"
        log_line "DISPATCHED=${'$'}query"
      fi
    done
) </dev/null >/dev/null 2>&1 &

listener_pid=${'$'}!
echo "${'$'}listener_pid" > "${'$'}PIDFILE"
log_line "LISTENER_PID=${'$'}(cat "${'$'}PIDFILE" 2>/dev/null)"
log_line 'LISTENER_RUNNING=1'
log_line 'BRIDGE_MODE=DIRECT_AM_START'
        """.trimIndent()

        val script = scriptTemplate
            .replace("__DEBUG_PATH__", debugPath)
            .replace("__TARGET_PACKAGE__", targetPackage)

        shell(connection, "rm -f '$debugPath' /data/local/tmp/vietmitv_assistant_bridge.pid /data/local/tmp/vietmitv_assistant_bridge.sh")
        val encoded = Base64.encodeToString(script.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val install = "echo $encoded | base64 -d > /data/local/tmp/vietmitv_assistant_bridge.sh && chmod 700 /data/local/tmp/vietmitv_assistant_bridge.sh"
        val installResult = shell(connection, install)
        if (installResult.isNotBlank()) localDebug("INSTALL_RESULT=${installResult.trim().take(500)}")

        shell(connection, "nohup sh /data/local/tmp/vietmitv_assistant_bridge.sh </dev/null >/dev/null 2>&1 &")
        Thread.sleep(1000)
        shell(connection, "printf '%s\n' 'SCRIPT_LAUNCHED=1' >> '$debugPath'")
        localDebug("LISTENER_SCRIPT_INSTALLED=1")
        localDebug("BRIDGE_TARGET_PACKAGE=$targetPackage")
        return true
    }

    private fun shell(connection: AdbConnection, command: String): String {
        val stream = connection.open("shell:$command")
        val out = StringBuilder()
        return try {
            while (!stream.isClosed && out.length < 8192) {
                val bytes = stream.read()
                if (bytes.isEmpty()) break
                out.append(String(bytes, Charsets.UTF_8))
            }
            out.toString()
        } catch (_: Exception) {
            out.toString()
        } finally {
            try { stream.close() } catch (_: Exception) {}
        }
    }

    private fun localDebug(message: String) {
        try {
            localLog.parentFile?.mkdirs()
            localLog.appendText(message + "\n")
        } catch (_: Exception) {}
    }

    private fun loadOrCreateCrypto(): AdbCrypto {
        val dir = File(context.filesDir, "adb")
        if (!dir.exists()) dir.mkdirs()
        val privateKey = File(dir, "adbkey")
        val publicKey = File(dir, "adbkey.pub")
        return if (privateKey.exists() && publicKey.exists()) {
            AdbCrypto.loadAdbKeyPair(SelfAdbBase64, privateKey, publicKey)
        } else {
            AdbCrypto.generateAdbKeyPair(SelfAdbBase64).also { it.saveAdbKeyPair(privateKey, publicKey) }
        }
    }
}
