package com.vietmitv.youtubevoice

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/** Restarts the bridge after boot, app update, or an explicit watchdog alarm. */
class KeepAliveReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            ACTION_WATCHDOG -> {
                try {
                    ContextCompat.startForegroundService(
                        context,
                        Intent(context, SelfAdbService::class.java)
                    )
                } catch (_: Exception) {
                    // Some TV firmware blocks FGS launch at boot; START_STICKY
                    // and the next watchdog alarm will get another chance.
                }
                schedule(context)
            }
        }
    }

    companion object {
        const val ACTION_WATCHDOG = "com.vietmitv.youtubevoice.action.WATCHDOG"

        fun schedule(context: Context) {
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
            val pi = android.app.PendingIntent.getBroadcast(
                context,
                701,
                Intent(context, KeepAliveReceiver::class.java).setAction(ACTION_WATCHDOG),
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            val interval = 15 * 60 * 1000L
            val first = android.os.SystemClock.elapsedRealtime() + interval
            alarm.setInexactRepeating(
                android.app.AlarmManager.ELAPSED_REALTIME_WAKEUP,
                first,
                interval,
                pi
            )
        }
    }
}
