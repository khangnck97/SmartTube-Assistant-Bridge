# VietMITV YouTube Voice - ADB Role Bridge DEBUG 4

Bản này sửa lỗi debug runtime thấy trên TV: `cmd role get-role-holders` không tồn tại trên firmware đó, đồng thời sửa `printf` để log có newline thật thay vì hiện literal `\\n`.

Bridge giữ Google Katniss làm ASSISTANT role và dùng đúng logcat tag `katniss_interactor_StreamingTextView` để bắt truy vấn, theo kiến trúc VietMITV gốc.
