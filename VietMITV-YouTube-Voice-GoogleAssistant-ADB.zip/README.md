# YouTube Voice — Google Assistant + local ADB bridge

Bản này bỏ SpeechRecognizer riêng của app.

Luồng:
Google Assistant/Google TV -> logcat của Katniss -> local ADB bridge -> VoiceOverlayService -> Tizentube hoặc SmartTube.

Đã bóc từ APK VietMITV:
- local ADB host: 127.0.0.1
- các lệnh cấp quyền: WRITE_SECURE_SETTINGS và SYSTEM_ALERT_WINDOW
- logcat tag: katniss_interactor_StreamingTextView
- action nội bộ được thay bằng package mới của app.

LƯU Ý:
APK không thể tự bật ADB hay tự vượt qua hộp thoại ủy quyền ADB. Cầu nối chỉ hoạt động khi TV firmware đã có ADB daemon nghe trên local TCP và khóa ADB của app được ủy quyền. adblib 1.3 được dùng để nói chuyện với ADB daemon.
