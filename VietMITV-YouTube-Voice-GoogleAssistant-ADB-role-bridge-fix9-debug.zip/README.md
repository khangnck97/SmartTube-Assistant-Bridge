# VietMITV ADB Role Bridge DEBUG 6

This version fixes the main runtime problem seen in DEBUG 5: the logcat listener is now kept on the authenticated ADB transport instead of being launched as a detached background shell process. The ADB connection remains alive while the listener reads Katniss logs.

The bridge keeps Google Katniss as the Android ASSISTANT role and forwards recognized text to VoiceOverlayService.
