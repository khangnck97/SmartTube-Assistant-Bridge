# VietMITV YouTube Voice – ADB Role Bridge FIX11

FIX11 sửa lỗi biên dịch Kotlin do các biến shell `$DEBUG`, `$PIDFILE`, `$line`, `$query`, `$!` bị Kotlin hiểu nhầm. Script shell được dựng bằng placeholder và escape dollar đúng cách.

Listener dùng `logcat -b all` và lọc `katniss_interactor_StreamingTextView`, sau đó gửi query sang VoiceOverlayService.
\nFIX14: "Mở video" / "mo video" now launches the selected player only; it no longer constructs a YouTube search URL. Search is only triggered by explicit search phrases such as "tìm ...", "tìm kiếm ...", "search ...", or "YouTube ...".\n

## Test2 command behavior
- `Mở video` -> launches the selected player only.
- `Mở video Sơn Tùng` -> no video ID is present, so it falls back to YouTube search for `Sơn Tùng`.
- `Mở video https://youtu.be/XXXXXXXXXXX` -> opens the exact video URL (when a valid 11-character ID is present).
- `Mở video XXXXXXXXXXX` -> treats the 11-character value as a YouTube video ID and opens it.
- `Tìm ...` / `Tìm kiếm ...` / `Search ...` -> search.
- `YouTube ...` -> search.
