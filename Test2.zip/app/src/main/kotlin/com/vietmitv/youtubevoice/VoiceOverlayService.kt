package com.vietmitv.youtubevoice

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import java.util.Locale

class VoiceOverlayService : Service() {

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(
            77,
            Notification.Builder(this, "voice")
                .setContentTitle("YouTube Voice")
                .setContentText("Đang chờ Google Assistant")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_ASSISTANT_RESULT) {
            val query = intent.getStringExtra("assistant_query").orEmpty().trim()
            if (query.isNotEmpty()) {
                handleAssistantCommand(query)
            }
        }
        return START_STICKY
    }

    private fun handleAssistantCommand(raw: String) {
        val original = raw.trim()
        if (original.isEmpty()) return

        val normalized = original
            .lowercase(Locale.ROOT)
            .replace(Regex("\\s+"), " ")

        // "Mở video" with no title remains launch-only.
        if (normalized == "mở video" || normalized == "mo video" ||
            normalized == "mở" || normalized == "mo" ||
            normalized == "mở youtube" || normalized == "mo youtube") {
            launchSelectedPlayer()
            return
        }

        // "Mở video <title/url/id>":
        // 1) If the recognized text contains a real YouTube URL or 11-char ID,
        //    open that exact video.
        // 2) If no ID can be extracted, FALL BACK to searching the title.
        if (normalized.startsWith("mở video ") || normalized.startsWith("mo video ")) {
            val titleOrTarget = original
                .replaceFirst(Regex("^(?i)mở\\s+video\\s+"), "")
                .replaceFirst(Regex("^(?i)mo\\s+video\\s+"), "")
                .trim()

            if (titleOrTarget.isEmpty()) {
                launchSelectedPlayer()
                return
            }

            val videoId = extractYoutubeVideoId(titleOrTarget)
            if (videoId != null) {
                openYoutubeVideo(videoId)
            } else {
                // No video ID is available in the spoken command, so do not
                // invent one. Search the spoken title instead.
                openYoutubeSearch(titleOrTarget)
            }
            return
        }

        // Search is reserved for explicit search language.
        if (normalized.startsWith("tìm kiếm ") ||
            normalized.startsWith("tim kiem ") ||
            normalized.startsWith("tìm ") ||
            normalized.startsWith("tim ") ||
            normalized.startsWith("search ")) {

            val query = original
                .replaceFirst(Regex("^(?i)tìm\\s+kiếm\\s+"), "")
                .replaceFirst(Regex("^(?i)tim\\s+kiem\\s+"), "")
                .replaceFirst(Regex("^(?i)tìm\\s+"), "")
                .replaceFirst(Regex("^(?i)tim\\s+"), "")
                .replaceFirst(Regex("^(?i)search\\s+"), "")
                .trim()

            if (query.isNotEmpty()) {
                openYoutubeSearch(query)
            } else {
                launchSelectedPlayer()
            }
            return
        }

        // "YouTube <content>" is still a search command.
        val youtubeQuery = original
            .replaceFirst(Regex("^(?i)youtube\\s*"), "")
            .trim()

        if (normalized.startsWith("youtube ") && youtubeQuery.isNotEmpty()) {
            openYoutubeSearch(youtubeQuery)
            return
        }

        // Other commands keep the previous safe behavior.
        launchSelectedPlayer()
    }

    /**
     * Extract a genuine YouTube video ID from a spoken/pasted target.
     * Returns null for titles such as "Sơn Tùng", so the caller can fall back
     * to search rather than constructing a bogus watch URL.
     */
    private fun extractYoutubeVideoId(value: String): String? {
        val s = value.trim()

        // Bare 11-character YouTube ID.
        if (Regex("^[A-Za-z0-9_-]{11}$").matches(s)) return s

        val patterns = listOf(
            Regex("""(?:v=|youtu\.be/|youtube\.com/shorts/|youtube\.com/live/)([A-Za-z0-9_-]{11})"""),
            Regex("""youtube\.com/watch[^\\s]*[?&]v=([A-Za-z0-9_-]{11})""")
        )

        for (pattern in patterns) {
            val match = pattern.find(s)
            if (match != null) return match.groupValues[1]
        }

        return null
    }

    private fun openYoutubeVideo(videoId: String) {
        val selected = selectedPackage()
        val installed = try {
            packageManager.getApplicationInfo(selected, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }

        val url = "https://www.youtube.com/watch?v=${Uri.encode(videoId)}"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (installed) setPackage(selected)
        }

        try {
            startActivity(intent)
        } catch (_: Exception) {
            // If the selected player cannot consume the exact video URL,
            // fall back to its launcher rather than turning the ID into search.
            launchSelectedPlayer()
        }
    }

    private fun selectedPackage(): String {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        return prefs.getString(
            "youtube_package",
            "io.gh.reisxd.tizentube.cobalt"
        ) ?: "io.gh.reisxd.tizentube.cobalt"
    }

    private fun launchSelectedPlayer() {
        val selected = selectedPackage()
        try {
            val launch = packageManager.getLaunchIntentForPackage(selected)
                ?: throw IllegalStateException("Package not installed: $selected")
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launch)
        } catch (_: Exception) {
            // No search fallback here: "mở video" must never trigger a search.
        }
    }

    private fun openYoutubeSearch(query: String) {
        val selected = selectedPackage()
        val installed = try {
            packageManager.getApplicationInfo(selected, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }

        val url = "https://www.youtube.com/results?search_query=${Uri.encode(query)}"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (installed) setPackage(selected)
        }

        try {
            startActivity(intent)
        } catch (_: Exception) {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            )
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(
                    NotificationChannel(
                        "voice",
                        "Google Assistant bridge",
                        NotificationManager.IMPORTANCE_LOW
                    )
                )
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_ASSISTANT_RESULT =
            "com.vietmitv.youtubevoice.action.HANDLE_ASSISTANT_RESULT"

        fun openSearchFromActivity(context: Context, query: String) {
            val i = Intent(context, VoiceOverlayService::class.java).apply {
                action = ACTION_ASSISTANT_RESULT
                putExtra("assistant_query", query)
            }
            context.startForegroundService(i)
        }
    }
}
