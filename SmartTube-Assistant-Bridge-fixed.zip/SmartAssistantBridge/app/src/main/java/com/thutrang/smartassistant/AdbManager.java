package com.thutrang.smartassistant;

import android.content.Context;
import android.util.Base64;
import com.tananaev.adblib.AdbBase64;
import com.tananaev.adblib.AdbConnection;
import com.tananaev.adblib.AdbCrypto;
import com.tananaev.adblib.AdbStream;
import java.io.File;
import java.io.IOException;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public final class AdbManager {
    private final Context context;
    private AdbConnection connection;

    public AdbManager(Context context) { this.context = context.getApplicationContext(); }

    private AdbCrypto crypto() throws Exception {
        File dir = new File(context.getFilesDir(), "adb");
        if (!dir.exists()) dir.mkdirs();
        File priv = new File(dir, "vxm_adbkey");
        File pub = new File(dir, "vxm_adbkey.pub");
        AdbBase64 b64 = data -> Base64.encodeToString(data, Base64.NO_WRAP);
        if (priv.exists() && pub.exists()) return AdbCrypto.loadAdbKeyPair(b64, priv, pub);
        AdbCrypto c = AdbCrypto.generateAdbKeyPair(b64);
        c.saveAdbKeyPair(priv, pub);
        return c;
    }

    public synchronized boolean connect() throws Exception {
        close();
        Socket socket = new Socket("127.0.0.1", 5555);
        socket.setTcpNoDelay(true);
        connection = AdbConnection.create(socket, crypto());
        // false is important: on the first connection the ADB daemon sends an
        // AUTH challenge. adblib must be allowed to send our public key after
        // the first signature is rejected; this is what makes Android show
        // the "Allow USB/Wireless debugging?" authorization dialog.
        return connection.connect(15000, java.util.concurrent.TimeUnit.MILLISECONDS, false);
    }

    public synchronized String shell(String command) throws Exception {
        if (connection == null) connect();
        AdbStream s = connection.open("shell:" + command);
        StringBuilder out = new StringBuilder();
        try {
            while (true) {
                byte[] p = s.read();
                if (p == null) break;
                String t = new String(p, StandardCharsets.UTF_8);
                out.append(t);
                if (s.isClosed()) break;
                if (t.indexOf('\0') >= 0) break;
            }
        } catch (IOException ignored) { }
        try { s.close(); } catch (Exception ignored) { }
        return out.toString();
    }

    public synchronized void close() {
        try { if (connection != null) connection.close(); } catch (Exception ignored) { }
        connection = null;
    }
}
