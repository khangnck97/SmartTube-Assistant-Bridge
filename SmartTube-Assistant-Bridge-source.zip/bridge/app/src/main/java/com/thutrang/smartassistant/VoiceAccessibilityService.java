package com.thutrang.smartassistant;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.SystemClock;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Watches the Google TV/Katniss assistant UI.  VietMITV keeps Katniss as the
 * system assistant and uses an accessibility hook + self-ADB to intercept the
 * recognized text; it does not replace the Assistant role with its own APK.
 */
public class VoiceAccessibilityService extends AccessibilityService {
    private static final String TAG = "SmartTubeA11y";
    private static final String KATNISS = "com.google.android.katniss";
    private static final String BRIDGE = "com.thutrang.smartassistant";
    private long lastDispatch;
    private String lastQuery = "";

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        CharSequence pkg = event.getPackageName();
        if (pkg == null || !KATNISS.contentEquals(pkg)) return;
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                && event.getEventType() != AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED
                && event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;

        String query = findUsefulText(event.getSource());
        if (query == null || query.length() < 2) return;
        if (looksLikeUiText(query)) return;
        long now = SystemClock.uptimeMillis();
        if (query.equals(lastQuery) && now - lastDispatch < 2500) return;
        if (now - lastDispatch < 500) return;

        lastQuery = query;
        lastDispatch = now;
        Log.i(TAG, "Katniss query=" + query);
        dispatch(query);
    }

    private String findUsefulText(AccessibilityNodeInfo root) {
        if (root == null) return null;
        ArrayList<AccessibilityNodeInfo> nodes = new ArrayList<>();
        collect(root, nodes, 0);
        String best = null;
        for (AccessibilityNodeInfo n : nodes) {
            CharSequence t = n.getText();
            if (t == null) t = n.getContentDescription();
            if (t == null) continue;
            String s = t.toString().trim();
            if (s.length() < 2 || s.length() > 300) continue;
            if (best == null || s.length() > best.length()) best = s;
        }
        return best;
    }

    private void collect(AccessibilityNodeInfo n, List<AccessibilityNodeInfo> out, int depth) {
        if (n == null || depth > 12) return;
        out.add(n);
        for (int i = 0; i < n.getChildCount(); i++) collect(n.getChild(i), out, depth + 1);
    }

    private boolean looksLikeUiText(String s) {
        String x = s.toLowerCase(Locale.ROOT);
        return x.equals("google") || x.equals("assistant") || x.equals("google assistant")
                || x.contains("đang nghe") || x.contains("listening")
                || x.contains("try saying") || x.contains("thử nói");
    }

    private void dispatch(String query) {
        new Thread(() -> {
            try {
                AdbManager adb = new AdbManager(this);
                adb.connect();
                adb.shell("am force-stop " + KATNISS);
                adb.shell("am startservice -n " + BRIDGE + "/.VoiceOverlayService"
                        + " -a " + BRIDGE + ".HANDLE_VOICE_RESULT"
                        + " --es mobile_voice_result " + shellQuote(query));
                adb.close();
            } catch (Throwable t) {
                Log.e(TAG, "dispatch failed", t);
                try {
                    Intent i = new Intent(this, VoiceOverlayService.class);
                    i.setAction(BRIDGE + ".HANDLE_VOICE_RESULT");
                    i.putExtra("mobile_voice_result", query);
                    startService(i);
                } catch (Throwable ignored) { }
            }
        }, "smarttube-a11y-dispatch").start();
    }

    private static String shellQuote(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }

    @Override public void onInterrupt() { }
}
