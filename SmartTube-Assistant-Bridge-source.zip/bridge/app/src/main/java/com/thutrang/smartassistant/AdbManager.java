package com.thutrang.smartassistant;

import android.content.Context;
import android.util.Base64;

import com.tananaev.adblib.AdbBase64;
import com.tananaev.adblib.AdbConnection;
import com.tananaev.adblib.AdbCrypto;
import com.tananaev.adblib.AdbStream;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

/**
 * Legacy TCP ADB client used by VietMITV-style self-ADB authorization.
 *
 * Important: do NOT use Android 11 Wireless Debugging pairing/TLS here.
 * On the target Android TV firmware, adbd listens on localhost:5555 and
 * uses the legacy RSA AUTH flow. tananaev/adblib sends the RSA public key
 * after the first signature is rejected, which is what causes Android's
 * normal "Allow USB debugging?" authorization dialog to appear.
 */
public final class AdbManager {
    private static final int ADB_PORT = 5555;
    private final Context context;
    private AdbCrypto crypto;
    private AdbConnection connection;

    private static final AdbBase64 BASE64 = data ->
            Base64.encodeToString(data, Base64.NO_WRAP);

    public AdbManager(Context context) {
        this.context = context.getApplicationContext();
    }

    private synchronized AdbCrypto getCrypto() throws Exception {
        if (crypto != null) return crypto;

        File dir = new File(context.getFilesDir(), "adb");
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IOException("Không tạo được thư mục khóa ADB");
        }
        File privateKey = new File(dir, "private_key");
        File publicKey = new File(dir, "public_key");

        try {
            if (privateKey.exists() && publicKey.exists()) {
                crypto = AdbCrypto.loadAdbKeyPair(BASE64, privateKey, publicKey);
            }
        } catch (Exception ignored) {
            // Regenerate a clean pair if an old/incompatible pair exists.
            privateKey.delete();
            publicKey.delete();
        }

        if (crypto == null) {
            crypto = AdbCrypto.generateAdbKeyPair(BASE64);
            crypto.saveAdbKeyPair(privateKey, publicKey);
        }
        return crypto;
    }

    /**
     * Connects to the TV's local legacy adbd. The final argument is false on
     * purpose: when the first RSA signature is rejected, adblib must continue
     * and send AUTH_TYPE_RSA_PUBLIC so Android can show its authorization UI.
     */
    public synchronized void connect() throws Exception {
        closeConnectionOnly();

        Socket socket = new Socket("127.0.0.1", ADB_PORT);
        socket.setTcpNoDelay(true);
        socket.setSoTimeout(35000);

        AdbConnection c = AdbConnection.create(socket, getCrypto());
        connection = c;
        try {
            boolean ok = c.connect(30, TimeUnit.SECONDS, false);
            if (!ok) {
                throw new IOException("ADB không phản hồi trong 30 giây");
            }
        } catch (Exception e) {
            try { c.close(); } catch (Exception ignored) { }
            connection = null;
            throw e;
        }
    }

    public synchronized boolean isConnected() {
        return connection != null;
    }

    public synchronized String shell(String command) throws Exception {
        if (!isConnected()) connect();

        AdbStream stream = connection.open("shell:" + command);
        try (AdbStream ignored = stream; InputStream input = stream.openInputStream()) {
            StringBuilder out = new StringBuilder();
            byte[] buffer = new byte[4096];
            int n;
            while ((n = input.read(buffer)) != -1) {
                out.append(new String(buffer, 0, n, StandardCharsets.UTF_8));
            }
            return out.toString();
        }
    }

    private synchronized void closeConnectionOnly() {
        if (connection != null) {
            try { connection.close(); } catch (Exception ignored) { }
            connection = null;
        }
    }

    public synchronized void close() {
        closeConnectionOnly();
    }
}
