package com.thutrang.smartassistant;

import android.content.Context;
import android.util.Base64;
import com.tananaev.adblib.AdbBase64;
import com.tananaev.adblib.AdbConnection;
import com.tananaev.adblib.AdbCrypto;
import com.tananaev.adblib.AdbStream;
import java.io.File;
import java.io.IOException;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public final class AdbManager {
    private final Context context;
    private AdbConnection connection;

    public AdbManager(Context context) { this.context = context.getApplicationContext(); }

    private AdbCrypto crypto() throws Exception {
        File dir = new File(context.getFilesDir(), "adb");
        if (!dir.exists()) dir.mkdirs();
        File priv = new File(dir, "vxm_adbkey");
        File pub = new File(dir, "vxm_adbkey.pub");
        AdbBase64 b64 = data -> Base64.encodeToString(data, Base64.NO_WRAP);
        if (priv.exists() && pub.exists()) return AdbCrypto.loadAdbKeyPair(b64, priv, pub);
        AdbCrypto c = AdbCrypto.generateAdbKeyPair(b64);
        c.saveAdbKeyPair(priv, pub);
        return c;
    }

    public synchronized void connect() throws Exception {
        close();
        Socket socket = connectLocalAdb();
        socket.setTcpNoDelay(true);
        connection = AdbConnection.create(socket, crypto());
        connection.connect(4000, java.util.concurrent.TimeUnit.MILLISECONDS, true);
    }

    private Socket connectLocalAdb() throws Exception {
        // Try the standard local ADB TCP endpoint first. This only succeeds when
        // the TV firmware exposes adbd on loopback; the app cannot enable adbd
        // by itself without an existing privileged/debug channel.
        int[] ports = {5555, 5556, 5557, 5558};
        Exception last = null;
        for (int port : ports) {
            try {
                Socket s = new Socket();
                s.connect(new java.net.InetSocketAddress("127.0.0.1", port), 1200);
                s.setTcpNoDelay(true);
                return s;
            } catch (Exception e) { last = e; }
        }
        throw last != null ? last : new IOException("Local ADB endpoint unavailable");
    }

    public synchronized String shell(String command) throws Exception {
        if (connection == null) connect();
        AdbStream s = connection.open("shell:" + command);
        StringBuilder out = new StringBuilder();
        try {
            while (true) {
                byte[] p = s.read();
                if (p == null) break;
                String t = new String(p, StandardCharsets.UTF_8);
                out.append(t);
                if (s.isClosed()) break;
                if (t.indexOf('\0') >= 0) break;
            }
        } catch (IOException ignored) { }
        try { s.close(); } catch (Exception ignored) { }
        return out.toString();
    }

    public synchronized void close() {
        try { if (connection != null) connection.close(); } catch (Exception ignored) { }
        connection = null;
    }
}
