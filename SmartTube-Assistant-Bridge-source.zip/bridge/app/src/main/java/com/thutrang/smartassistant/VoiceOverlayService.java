package com.thutrang.smartassistant;

import android.app.*;
import android.content.*;
import android.os.*;
import android.provider.Settings;
import android.net.Uri;
import android.util.Log;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class VoiceOverlayService extends Service {
    private static final String TAG = "SmartTubeBridge";
    private volatile boolean running;
    private Thread monitor;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        if (Build.VERSION.SDK_INT >= 26) startForeground(1001, notification());
        startMonitor();
    }

    @Override public int onStartCommand(Intent intent, int flags, int id) {
        if (intent != null && "com.thutrang.smartassistant.HANDLE_VOICE_RESULT".equals(intent.getAction())) {
            openSmartTube(intent.getStringExtra("mobile_voice_result"));
        }
        return START_STICKY;
    }

    private void startMonitor() {
        if (running) return;
        running = true;
        monitor = new Thread(() -> {
            AdbManager adb = new AdbManager(this);
            com.tananaev.adblib.AdbStream stream = null;
            try {
                adb.connect();

                // Match VietMITV's working strategy: keep a single long-lived
                // logcat shell alive and let the TV shell parse the query.
                // Polling `logcat -d` misses the short-lived Katniss lines.
                String cmd = "logcat -v threadtime -s katniss_interactor_StreamingTextView:I | "
                        + "while read -r line; do "
                        + "query=$(echo \"$line\" | awk -F'[()]' '{print $2}'); "
                        + "if [ -n \"$query\" ]; then "
                        + "log -p i -t SmartTubeBridgeShell \"query=$query\"; "
                        + "am force-stop com.google.android.katniss >/dev/null 2>&1; "
                        + "am startservice -n com.thutrang.smartassistant/.VoiceOverlayService "
                        + "-a com.thutrang.smartassistant.HANDLE_VOICE_RESULT "
                        + "--es mobile_voice_result \"$query\"; "
                        + "fi; done";

                stream = adb.shellStream(cmd);
                while (running) {
                    try {
                        // Keep consuming the long-lived stream. The shell itself
                        // performs the dispatch; Java does not need to parse it.
                        stream.read();
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            } catch (Throwable t) {
                Log.e(TAG, "monitor stopped", t);
            } finally {
                if (stream != null) {
                    try { stream.close(); } catch (Exception ignored) {}
                }
                adb.close();
            }
        }, "smarttube-logcat");
        monitor.start();
    }

    private String parseQuery(String line) {
        if (line == null || !line.contains("katniss_interactor_StreamingTextView")) return null;
        int a = line.indexOf('('), b = line.indexOf(')', a + 1);
        if (a >= 0 && b > a) return line.substring(a + 1, b).trim();
        return null;
    }

    private void openSmartTube(String query) {
        try {
            Intent i = new Intent("android.intent.action.SEARCH");
            i.setComponent(new ComponentName("com.teamsmart.videomanager.tv", "com.liskovsoft.smartyoutubetv2.tv.launchers.SearchLauncherActivity"));
            if (query != null && !query.trim().isEmpty()) i.putExtra("query", query.trim());
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
            return;
        } catch (Throwable ignored) { }
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage("com.teamsmart.videomanager.tv");
            if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP); startActivity(i); }
        } catch (Throwable t) { Log.e(TAG, "SmartTube launch failed", t); }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("bridge", "SmartTube Bridge", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }
    private Notification notification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "bridge") : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("SmartTube Bridge").setContentText("Google Assistant → SmartTube").build();
    }
    @Override public IBinder onBind(Intent i) { return null; }
    @Override public void onDestroy() { running = false; super.onDestroy(); }
}
