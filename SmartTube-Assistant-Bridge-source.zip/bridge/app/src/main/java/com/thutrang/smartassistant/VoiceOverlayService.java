package com.thutrang.smartassistant;

import android.app.*;
import android.content.*;
import android.os.*;
import android.provider.Settings;
import android.net.Uri;
import android.util.Log;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class VoiceOverlayService extends Service {
    private static final String TAG = "SmartTubeBridge";
    private volatile boolean running;
    private Thread monitor;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        if (Build.VERSION.SDK_INT >= 26) startForeground(1001, notification());
        startMonitor();
    }

    @Override public int onStartCommand(Intent intent, int flags, int id) {
        if (intent != null && "com.thutrang.smartassistant.HANDLE_VOICE_RESULT".equals(intent.getAction())) {
            openSmartTube(intent.getStringExtra("mobile_voice_result"));
        }
        return START_STICKY;
    }

    private void startMonitor() {
        // The actual interception is performed by VoiceAccessibilityService,
        // matching VietMITV's architecture. Keep this service alive so it can
        // receive HANDLE_VOICE_RESULT intents and launch SmartTube.
        running = true;
    }

    private String parseQuery(String line) {
        if (line == null || !line.contains("katniss_interactor_StreamingTextView")) return null;
        int a = line.indexOf('('), b = line.indexOf(')', a + 1);
        if (a >= 0 && b > a) return line.substring(a + 1, b).trim();
        return null;
    }

    private void openSmartTube(String query) {
        try {
            Intent i = new Intent("android.intent.action.SEARCH");
            i.setComponent(new ComponentName("com.teamsmart.videomanager.tv", "com.liskovsoft.smartyoutubetv2.tv.launchers.SearchLauncherActivity"));
            if (query != null && !query.trim().isEmpty()) i.putExtra("query", query.trim());
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
            return;
        } catch (Throwable ignored) { }
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage("com.teamsmart.videomanager.tv");
            if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP); startActivity(i); }
        } catch (Throwable t) { Log.e(TAG, "SmartTube launch failed", t); }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("bridge", "SmartTube Bridge", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }
    private Notification notification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "bridge") : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("SmartTube Bridge").setContentText("Google Assistant → SmartTube").build();
    }
    @Override public IBinder onBind(Intent i) { return null; }
    @Override public void onDestroy() { running = false; super.onDestroy(); }
}
