package com.thutrang.smartassistant;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService pool = Executors.newSingleThreadExecutor();
    private AdbManager adb;
    private TextView status;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        adb = new AdbManager(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setPadding(40,40,40,40);
        status = new TextView(this); status.setText("Chưa cấp quyền ADB"); status.setTextSize(18);

        Button grant = new Button(this);
        grant.setText("CẤP QUYỀN GỠ LỖI ADB");
        Button enable = new Button(this);
        enable.setText("BẬT chuyển hướng Google Assistant → SmartTube");
        Button disable = new Button(this); disable.setText("TẮT chuyển hướng");
        box.addView(status); box.addView(grant); box.addView(enable); box.addView(disable); setContentView(box);

        grant.setOnClickListener(v -> requestAdb());
        enable.setOnClickListener(v -> enableBridge());
        disable.setOnClickListener(v -> disableBridge());
    }

    private void requestAdb() {
        status.setText("Đang thử kết nối ADB nội bộ...");
        pool.execute(() -> {
            try {
                adb.connect();
                runOnUiThread(() -> status.setText("ADB đã được cấp quyền."));
            } catch (Exception e) {
                runOnUiThread(() -> {
                    status.setText("TV chưa mở ADB nội bộ. Mở Wireless debugging để bật ADB trên TV.");
                    try {
                        startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
                    } catch (Exception ignored) {
                        try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored2) {}
                    }
                });
            }
        });
    }

    private void enableBridge() {
        status.setText("Đang kết nối ADB nội bộ...");
        pool.execute(() -> {
            try {
                adb.connect();
                adb.shell("pm enable --user 0 com.google.android.katniss");
                adb.shell("pm grant com.thutrang.smartassistant android.permission.WRITE_SECURE_SETTINGS");
                adb.shell("appops set com.thutrang.smartassistant SYSTEM_ALERT_WINDOW allow");
                adb.shell("cmd role remove-role-holder android.app.role.ASSISTANT com.thutrang.smartassistant 0");
                adb.shell("cmd role add-role-holder android.app.role.ASSISTANT com.google.android.katniss 0");
                adb.shell("logcat -c");
                startService(new Intent(this, VoiceOverlayService.class));
                runOnUiThread(() -> status.setText("Đã bật. Nhấn nút Google Assistant và nói lệnh YouTube."));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Chưa có ADB nội bộ: " + e.getClass().getSimpleName()));
            }
        });
    }

    private void disableBridge() {
        pool.execute(() -> {
            try { adb.shell("cmd role add-role-holder android.app.role.ASSISTANT com.google.android.katniss 0"); } catch (Exception ignored) {}
            runOnUiThread(() -> status.setText("Đã tắt bridge."));
        });
    }

    @Override protected void onDestroy() { pool.shutdownNow(); adb.close(); super.onDestroy(); }
}
