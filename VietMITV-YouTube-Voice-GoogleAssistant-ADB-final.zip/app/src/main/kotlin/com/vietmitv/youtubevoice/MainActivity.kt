package com.vietmitv.youtubevoice

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.core.content.ContextCompat

class MainActivity : androidx.appcompat.app.AppCompatActivity() {
    private lateinit var radioTizen: RadioButton
    private lateinit var radioSmart: RadioButton
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 32, 48, 32)
        }

        root.addView(TextView(this).apply {
            text = "YouTube không quảng cáo"
            textSize = 26f
            gravity = Gravity.CENTER
        })

        val group = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            setPadding(0, 24, 0, 12)
        }
        radioTizen = RadioButton(this).apply {
            text = "Tizentube"
            textSize = 20f
            tag = "io.gh.reisxd.tizentube.cobalt"
        }
        radioSmart = RadioButton(this).apply {
            text = "SmartTube"
            textSize = 20f
            tag = "com.teamsmart.videomanager.tv"
        }
        group.addView(radioTizen)
        group.addView(radioSmart)

        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        if (prefs.getString("youtube_package", "") == radioSmart.tag) {
            radioSmart.isChecked = true
        } else {
            radioTizen.isChecked = true
        }

        group.setOnCheckedChangeListener { _, id ->
            val selected = findViewById<RadioButton>(id)
            prefs.edit().putString("youtube_package", selected.tag.toString()).apply()
        }
        root.addView(group)

        status = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            text = adbStatus()
        }
        root.addView(status)

        val adb = Button(this).apply {
            text = "KÍCH HOẠT CẦU NỐI ADB"
            textSize = 18f
            setOnClickListener {
                ContextCompat.startForegroundService(
                    this@MainActivity,
                    Intent(this@MainActivity, SelfAdbService::class.java)
                )
                Toast.makeText(
                    this@MainActivity,
                    "Đang kiểm tra ADB nội bộ…",
                    Toast.LENGTH_LONG
                ).show()
                root.postDelayed({ status.text = adbStatus() }, 2500)
            }
        }
        root.addView(adb)

        val test = Button(this).apply {
            text = "▶ TEST: MỞ TÌM KIẾM"
            textSize = 18f
            setOnClickListener {
                VoiceOverlayService.openSearchFromActivity(
                    this@MainActivity,
                    "YouTube"
                )
            }
        }
        root.addView(test)

        setContentView(root)
    }

    private fun adbStatus(): String {
        return if (getSharedPreferences("settings", MODE_PRIVATE)
                .getBoolean("adb_ready", false)
        ) {
            "ADB nội bộ: ĐÃ KẾT NỐI"
        } else {
            "ADB nội bộ: chưa kết nối"
        }
    }
}
