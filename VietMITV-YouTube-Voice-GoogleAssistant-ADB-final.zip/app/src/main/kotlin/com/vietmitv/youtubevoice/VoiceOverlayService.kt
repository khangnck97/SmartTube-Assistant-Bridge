package com.vietmitv.youtubevoice

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import java.util.Locale

class VoiceOverlayService : Service() {

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(
            77,
            Notification.Builder(this, "voice")
                .setContentTitle("YouTube Voice")
                .setContentText("Đang chờ Google Assistant")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_ASSISTANT_RESULT) {
            val query = intent.getStringExtra("assistant_query").orEmpty().trim()
            if (query.isNotEmpty()) {
                handleAssistantCommand(query)
            }
        }
        return START_STICKY
    }

    private fun handleAssistantCommand(raw: String) {
        // The ADB logcat bridge already receives the Google Assistant query.
        // Strip common wake/search words before opening YouTube.
        val query = raw
            .replace(
                Regex("(?i)^\\s*(mở|mo|tìm|tim|tìm kiếm|tim kiem|search|youtube)\\s*"),
                ""
            )
            .trim()
            .ifBlank { raw.trim() }

        openYoutubeSearch(query)
    }

    private fun openYoutubeSearch(query: String) {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val selected = prefs.getString(
            "youtube_package",
            "io.gh.reisxd.tizentube.cobalt"
        ) ?: "io.gh.reisxd.tizentube.cobalt"

        val installed = try {
            packageManager.getApplicationInfo(selected, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }

        val url = "https://www.youtube.com/results?search_query=${Uri.encode(query)}"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (installed) setPackage(selected)
        }

        try {
            startActivity(intent)
        } catch (_: Exception) {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            )
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(
                    NotificationChannel(
                        "voice",
                        "Google Assistant bridge",
                        NotificationManager.IMPORTANCE_LOW
                    )
                )
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_ASSISTANT_RESULT =
            "com.vietmitv.youtubevoice.action.HANDLE_ASSISTANT_RESULT"

        fun openSearchFromActivity(context: Context, query: String) {
            val i = Intent(context, VoiceOverlayService::class.java).apply {
                action = ACTION_ASSISTANT_RESULT
                putExtra("assistant_query", query)
            }
            context.startForegroundService(i)
        }
    }
}
