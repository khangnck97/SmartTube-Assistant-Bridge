# YouTube Voice — Google Assistant + local ADB

Bản sửa lỗi build của GoogleAssistant-ADB.

- Không dùng SpeechRecognizer riêng.
- Có Tizentube và SmartTube.
- Có SelfAdbService dùng local ADB khi TV đã có daemon/ủy quyền.
- Sửa lỗi Kotlin ở notification và shell string interpolation.

Lưu ý: Android không cho APK tự bật ADB hoặc tự vượt qua xác nhận ủy quyền ADB.
