package com.vietmitv.youtubevoice

import android.content.Context
import com.tananaev.adblib.AdbConnection
import com.tananaev.adblib.AdbCrypto
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit

/**
 * Persistent self-ADB bridge.
 *
 * Important difference from the previous builds: the logcat reader is NOT
 * started as a detached shell process.  It stays on the authenticated ADB
 * transport owned by this worker, so Android cannot kill the child shell when
 * the short shell command exits.  This is much closer to the original
 * VietMITV behavior, which keeps its ADB/logcat bridge alive.
 */
class SelfAdbWorker(private val context: Context) {
    private val ports = intArrayOf(5555, 5556, 5557, 5558)
    private val packageName = context.packageName
    private val debugPath = "/sdcard/Android/data/$packageName/files/assistant_bridge.log"

    fun runOnce(onAuthorized: () -> Unit): Boolean {
        localDebug("=== VietMITV Assistant Bridge FIX8 started ===")
        localDebug("time=" + java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.US).format(java.util.Date()))
        val crypto = try {
            loadOrCreateCrypto()
        } catch (e: Exception) {
            localDebug("KEY_ERROR: ${e.javaClass.simpleName}: ${e.message}")
            return false
        }

        for (port in ports) {
            localDebug("TRY_PORT=$port")
            var socket: Socket? = null
            var connection: AdbConnection? = null
            try {
                socket = Socket().apply {
                    tcpNoDelay = true
                    keepAlive = true
                    connect(InetSocketAddress("127.0.0.1", port), 1500)
                }
                connection = AdbConnection.create(socket, crypto)
                localDebug("ADB_SOCKET_CONNECTED=$port")
                if (!connection.connect(90, TimeUnit.SECONDS, false)) {
                    localDebug("ADB_CONNECT_FALSE=$port")
                    continue
                }

                localDebug("ADB_AUTHORIZED=$port")
                onAuthorized()
                prepare(connection)
                appendDebug(connection, "=== VietMITV Assistant Bridge FIX8 started ===")
                appendDebug(connection, "time=$(date)")
                appendDebug(connection, "assistant=$(settings get secure assistant 2>&1)")
                appendDebug(connection, "katniss=$(pm path com.google.android.katniss 2>&1)")
                appendDebug(connection, "Starting PERSISTENT logcat reader...")

                // This call intentionally blocks while the ADB connection and
                // logcat stream are alive.  If the stream dies, runOnce returns
                // false and SelfAdbService retries the connection.
                readAssistantLog(connection)
                localDebug("LOGCAT_STREAM_ENDED")
                return false
            } catch (e: Exception) {
                localDebug("ERROR: ${e.javaClass.simpleName}: ${e.message}")
                try { connection?.close() } catch (_: Exception) {}
                try { socket?.close() } catch (_: Exception) {}
            }
        }
        localDebug("NO_ADB_PORT_CONNECTED")
        return false
    }

    private fun prepare(connection: AdbConnection) {
        localDebug("PREPARE_START")
        shell(connection, "pm enable --user 0 com.google.android.katniss >/dev/null 2>&1")
        shell(connection, "cmd role remove-role-holder android.app.role.ASSISTANT $packageName 0 >/dev/null 2>&1")
        shell(connection, "cmd role add-role-holder android.app.role.ASSISTANT com.google.android.katniss 0 >/dev/null 2>&1")
        shell(connection, "pm grant $packageName android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1")
        shell(connection, "appops set $packageName SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1")
        shell(connection, "(while true; do appops set $packageName SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; sleep 60; done) >/dev/null 2>&1 &")
        localDebug("PREPARE_DONE")
    }

    private fun readAssistantLog(connection: AdbConnection) {
        // Match the exact tag/filter used by the original VietMITV APK.
        shell(connection, "logcat -b all -c >/dev/null 2>&1 || logcat -c")
        val stream = connection.open("shell:logcat -v threadtime -s katniss_interactor_StreamingTextView:I")
        val buffer = StringBuilder()
        try {
            while (!stream.isClosed) {
                val bytes = stream.read()
                if (bytes.isEmpty()) break
                buffer.append(String(bytes, Charsets.UTF_8))

                var nl = buffer.indexOf("\n")
                while (nl >= 0) {
                    val line = buffer.substring(0, nl).trimEnd('\r')
                    buffer.delete(0, nl + 1)
                    if (line.isNotBlank()) handleLogLine(connection, line)
                    nl = buffer.indexOf("\n")
                }
            }
        } finally {
            try { stream.close() } catch (_: Exception) {}
        }
    }

    private fun handleLogLine(connection: AdbConnection, line: String) {
        appendDebug(connection, "RAW: $line")

        // Original parser: text is enclosed in parentheses in the Katniss
        // StreamingTextView message. Prefer the LAST pair so PID parentheses
        // in log formatting cannot become the query.
        var query = ""
        val lastOpen = line.lastIndexOf('(')
        val lastClose = line.lastIndexOf(')')
        if (lastOpen >= 0 && lastClose > lastOpen) {
            query = line.substring(lastOpen + 1, lastClose).trim()
        }

        // Fallbacks for firmware variants that don't wrap the text in ().
        if (query.isBlank()) {
            val marker = "StreamingTextView"
            val p = line.indexOf(marker, ignoreCase = true)
            if (p >= 0) {
                query = line.substring(p + marker.length)
                    .substringAfter(':', "")
                    .trim()
                    .removeSurrounding("(", ")")
                    .trim()
            }
        }

        // Ignore obvious log metadata if the fallback accidentally captured it.
        if (query.matches(Regex("\\d+"))) query = ""

        if (query.isBlank()) {
            appendDebug(connection, "NO_QUERY_EXTRACTED")
            return
        }

        appendDebug(connection, "QUERY: $query")
        shell(connection, "log -p i -t VxmSelfAdbShell 'query=$query'")
        shell(connection, "am force-stop com.google.android.katniss >/dev/null 2>&1")
        shell(connection, "log -p i -t VxmSelfAdbShell 'stopped Katniss before dispatch'")
        val dispatch = "am startservice -n $packageName/.VoiceOverlayService -a com.vietmitv.youtubevoice.action.HANDLE_ASSISTANT_RESULT --es assistant_query ${shellQuote(query)}"
        val result = shell(connection, dispatch)
        appendDebug(connection, "DISPATCHED: $query")
        if (result.isNotBlank()) appendDebug(connection, "AM_RESULT: ${result.trim().take(500)}")
    }

    private fun shellQuote(value: String): String = "'" + value.replace("'", "'\\''") + "'"

    private fun appendDebug(connection: AdbConnection, message: String) {
        localDebug(message)
        val safe = message.replace("\\", "\\\\").replace("'", "'\\''")
        shell(connection, "mkdir -p \"$(dirname '$debugPath')\"; printf '%s\\n' '$safe' >> '$debugPath'")
    }

    private fun localDebug(message: String) {
        try {
            val file = File(context.getExternalFilesDir(null), "assistant_bridge.log")
            file.parentFile?.mkdirs()
            file.appendText(message + "\n")
        } catch (_: Exception) {
            // Never let debug logging break the bridge.
        }
    }

    private fun shell(connection: AdbConnection, command: String): String {
        val stream = connection.open("shell:$command")
        val out = StringBuilder()
        return try {
            while (!stream.isClosed && out.length < 8192) {
                val bytes = stream.read()
                if (bytes.isEmpty()) break
                out.append(String(bytes, Charsets.UTF_8))
            }
            out.toString()
        } catch (_: Exception) {
            out.toString()
        } finally {
            try { stream.close() } catch (_: Exception) {}
        }
    }

    private fun loadOrCreateCrypto(): AdbCrypto {
        val dir = File(context.filesDir, "adb")
        if (!dir.exists()) dir.mkdirs()
        val privateKey = File(dir, "adbkey")
        val publicKey = File(dir, "adbkey.pub")
        return if (privateKey.exists() && publicKey.exists()) {
            AdbCrypto.loadAdbKeyPair(SelfAdbBase64, privateKey, publicKey)
        } else {
            AdbCrypto.generateAdbKeyPair(SelfAdbBase64).also {
                it.saveAdbKeyPair(privateKey, publicKey)
            }
        }
    }
}
