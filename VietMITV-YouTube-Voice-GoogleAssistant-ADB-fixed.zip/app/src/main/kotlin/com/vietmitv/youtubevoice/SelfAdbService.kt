package com.vietmitv.youtubevoice

import android.app.*
import android.content.Intent
import android.os.*
import com.tananaev.adblib.AdbBase64
import com.tananaev.adblib.AdbConnection
import com.tananaev.adblib.AdbCrypto
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Base64
import java.util.concurrent.TimeUnit

/**
 * Local ADB bridge.
 *
 * This intentionally connects only to a local ADB daemon (127.0.0.1).
 * It can execute the same kind of commands used by VietMITV after the
 * TV has already authorized the app's ADB key. It cannot turn ADB on
 * or bypass an Android authorization prompt.
 */
class SelfAdbService : Service() {
    private val executor = java.util.concurrent.Executors.newSingleThreadExecutor()

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val n = Notification.Builder(this, "adb")
            .setContentTitle("YouTube Voice")
            .setContentText("Đang kiểm tra ADB nội bộ…")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
        startForeground(78, n)

        executor.execute {
            val result = connectAndPrepare()
            getSharedPreferences("settings", MODE_PRIVATE)
                .edit()
                .putBoolean("adb_ready", result)
                .apply()
        }
    }

    private fun connectAndPrepare(): Boolean {
        val crypto = try {
            loadOrCreateCrypto()
        } catch (_: Exception) {
            return false
        }

        // VietMITV's APK contains 127.0.0.1 and a self-ADB worker. We try
        // the normal local adbd port first, then a small set of common
        // alternate local ports used by TV firmware.
        val ports = intArrayOf(5555, 5556, 5557, 5558)
        for (port in ports) {
            var socket: Socket? = null
            var connection: AdbConnection? = null
            try {
                socket = Socket()
                socket.connect(InetSocketAddress("127.0.0.1", port), 700)
                connection = AdbConnection.create(socket, crypto)
                if (!connection.connect(2500, TimeUnit.MILLISECONDS, false)) {
                    connection.close()
                    continue
                }

                // These are the same privilege-enabling operations visible
                // in the original VietMITV APK, but with this app's package.
                runShell(connection, "pm grant $packageName android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1")
                runShell(connection, "appops set $packageName SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1")

                // Keep the app's overlay permission app-op healed while the
                // authorized local ADB connection remains available.
                runShell(
                    connection,
                    "(while true; do appops set $packageName SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; sleep 60; done) &"
                )

                // Bridge Google TV/Assistant speech text from the same
                // logcat tag used by the original APK.
                val receiver =
                    "logcat -v threadtime -s katniss_interactor_StreamingTextView:I | " +
                    "while read -r line; do " +
                    "query=$(echo \"$line\" | awk -F'[()]' '{print \$2}'); " +
                    "if [ -n \"$query\" ]; then " +
                    "am start-foreground-service -n $packageName/.VoiceOverlayService " +
                    "-a com.vietmitv.youtubevoice.action.HANDLE_ASSISTANT_RESULT " +
                    "--es assistant_query \"$query\"; " +
                    "fi; done"
                runShell(connection, "sh -c '$receiver' >/dev/null 2>&1 &")

                connection.close()
                socket.close()
                return true
            } catch (_: Exception) {
                try { connection?.close() } catch (_: Exception) {}
                try { socket?.close() } catch (_: Exception) {}
            }
        }
        return false
    }

    private fun runShell(connection: AdbConnection, command: String): String {
        val stream = connection.open("shell:$command")
        val out = StringBuilder()
        return try {
            while (true) {
                val bytes = stream.read()
                out.append(String(bytes, Charsets.UTF_8))
                if (stream.isClosed) break
                if (out.length > 4096) break
            }
            out.toString()
        } catch (_: Exception) {
            out.toString()
        } finally {
            try { stream.close() } catch (_: Exception) {}
        }
    }

    private fun loadOrCreateCrypto(): AdbCrypto {
        val dir = File(filesDir, "adb")
        if (!dir.exists()) dir.mkdirs()
        val privateKey = File(dir, "adbkey")
        val publicKey = File(dir, "adbkey.pub")
        val b64 = object : AdbBase64 {
            override fun encodeToString(data: ByteArray): String =
                Base64.getEncoder().encodeToString(data)
        }
        return if (privateKey.exists() && publicKey.exists()) {
            AdbCrypto.loadAdbKeyPair(b64, privateKey, publicKey)
        } else {
            AdbCrypto.generateAdbKeyPair(b64).also {
                it.saveAdbKeyPair(privateKey, publicKey)
            }
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(
                    NotificationChannel(
                        "adb",
                        "ADB bridge",
                        NotificationManager.IMPORTANCE_LOW
                    )
                )
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: android.content.Intent?): IBinder? = null
}
