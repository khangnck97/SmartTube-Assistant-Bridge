# YouTube Voice — Google Assistant + local ADB

Bản sửa lỗi build của GoogleAssistant-ADB.

- Không dùng SpeechRecognizer riêng.
- Có Tizentube và SmartTube.
- Có SelfAdbService dùng local ADB khi TV đã có daemon/ủy quyền.
- Sửa lỗi Kotlin ở notification và shell string interpolation.

Lưu ý: Android không cho APK tự bật ADB hoặc tự vượt qua xác nhận ủy quyền ADB.


## Assistant role behavior
This bridge follows the original VietMITV architecture: Google Katniss remains the Android ASSISTANT role. The bridge uses ADB to enable Katniss, restore the ASSISTANT role to `com.google.android.katniss`, clear logcat, then listen for `katniss_interactor_StreamingTextView` and forward the recognized query to `VoiceOverlayService`.


ROLE FIX follow-up: the Assistant logcat listener is installed as a base64-encoded temporary shell script to avoid nested shell quoting failures.
