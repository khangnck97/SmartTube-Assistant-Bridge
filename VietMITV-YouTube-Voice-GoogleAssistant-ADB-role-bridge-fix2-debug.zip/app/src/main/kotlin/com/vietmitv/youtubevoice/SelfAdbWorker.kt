package com.vietmitv.youtubevoice

import android.content.Context
import com.tananaev.adblib.AdbConnection
import com.tananaev.adblib.AdbCrypto
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit

/**
 * Self-ADB worker ported from the VietMITV architecture:
 * persistent local adbd connection, persistent key pair, authorization wait,
 * permission self-heal and reconnect/watchdog behavior.
 */
class SelfAdbWorker(private val context: Context) {
    private val ports = intArrayOf(5555, 5556, 5557, 5558)
    private val packageName = context.packageName

    fun runOnce(onAuthorized: () -> Unit): Boolean {
        val crypto = try { loadOrCreateCrypto() } catch (_: Exception) { return false }

        for (port in ports) {
            var socket: Socket? = null
            var connection: AdbConnection? = null
            try {
                socket = Socket()
                socket.tcpNoDelay = true
                socket.keepAlive = true
                socket.connect(InetSocketAddress("127.0.0.1", port), 1500)

                connection = AdbConnection.create(socket, crypto)

                // IMPORTANT: do not close this attempt after 2–3 seconds.
                // adblib performs the AUTH exchange here; adbd may need time
                // for Android to display and process the authorization dialog.
                val connected = connection.connect(90, TimeUnit.SECONDS, false)
                if (!connected) continue

                onAuthorized()
                prepare(connection)

                // Keep the ADB transport alive while the logcat bridge runs.
                startAssistantBridge(connection)
                return true
            } catch (_: Exception) {
                try { connection?.close() } catch (_: Exception) {}
                try { socket?.close() } catch (_: Exception) {}
            }
        }
        return false
    }

    private fun prepare(connection: AdbConnection) {
        // VietMITV does NOT replace Google Assistant with itself.
        // It keeps Google's Katniss as the ASSISTANT role, then listens to
        // Katniss' StreamingTextView log and forwards the recognized query
        // into this bridge. These are the exact role/enable operations found
        // in the original VietMITV APK.
        shell(connection, "pm enable --user 0 com.google.android.katniss >/dev/null 2>&1")
        shell(connection, "cmd role remove-role-holder android.app.role.ASSISTANT $packageName 0 >/dev/null 2>&1")
        shell(connection, "cmd role add-role-holder android.app.role.ASSISTANT com.google.android.katniss 0 >/dev/null 2>&1")

        shell(connection, "pm grant $packageName android.permission.WRITE_SECURE_SETTINGS >/dev/null 2>&1")
        shell(connection, "appops set $packageName SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1")
        shell(connection, "(while true; do appops set $packageName SYSTEM_ALERT_WINDOW allow >/dev/null 2>&1; sleep 60; done) >/dev/null 2>&1 &")
    }

    private fun startAssistantBridge(connection: AdbConnection) {
        val debugPath = "/sdcard/Android/data/$packageName/files/assistant_bridge.log"
        val command = """
            DEBUG="$debugPath"
            mkdir -p "$(dirname "\$DEBUG")"
            printf '%s\\n' "=== VietMITV Assistant Bridge started ===" >> "\$DEBUG"
            printf '%s\\n' "time=$(date)" >> "\$DEBUG"
            printf '%s\\n' "role=$(cmd role get-role-holders android.app.role.ASSISTANT 2>&1)" >> "\$DEBUG"
            printf '%s\\n' "assistant=$(settings get secure assistant 2>&1)" >> "\$DEBUG"
            printf '%s\\n' "katniss=$(pm path com.google.android.katniss 2>&1)" >> "\$DEBUG"
            printf '%s\\n' "Starting logcat listener..." >> "\$DEBUG"

            if [ -f /data/local/tmp/vietmitv_assistant_bridge.pid ]; then
              oldpid=$(cat /data/local/tmp/vietmitv_assistant_bridge.pid 2>/dev/null)
              [ -n "\$oldpid" ] && kill "\$oldpid" 2>/dev/null || true
            fi

            (
              logcat -v threadtime | while read -r line; do
                case "\$line" in
                  *katniss_interactor_StreamingTextView*)
                    printf '%s\\n' "RAW: \$line" >> "\$DEBUG"
                    query=$(echo "\$line" | awk -F'[()]' '{print \$2}')
                    if [ -n "\$query" ]; then
                      printf '%s\\n' "QUERY: \$query" >> "\$DEBUG"
                      log -p i -t VxmSelfAdbShell "query=\$query"
                      am force-stop com.google.android.katniss >/dev/null 2>&1
                      log -p i -t VxmSelfAdbShell "stopped Katniss before dispatch"
                      am start-foreground-service -n $packageName/.VoiceOverlayService \\
                        -a com.vietmitv.youtubevoice.action.HANDLE_ASSISTANT_RESULT \\
                        --es assistant_query "\$query" >> "\$DEBUG" 2>&1
                      printf '%s\\n' "DISPATCHED: \$query" >> "\$DEBUG"
                    fi
                  ;;
                esac
              done
            ) </dev/null >>"\$DEBUG" 2>&1 &
            echo \$! > /data/local/tmp/vietmitv_assistant_bridge.pid
            printf '%s\\n' "LISTENER_PID=$(cat /data/local/tmp/vietmitv_assistant_bridge.pid 2>/dev/null)" >> "\$DEBUG"
            printf '%s\\n' "LISTENER_RUNNING=1" >> "\$DEBUG"
        """.trimIndent()

        // Clear old logs before starting a fresh diagnostic session.
        shell(connection, "rm -f $debugPath /data/local/tmp/vietmitv_assistant_bridge.pid")

        val encoded = android.util.Base64.encodeToString(
            command.toByteArray(Charsets.UTF_8),
            android.util.Base64.NO_WRAP
        )
        val install = "echo $encoded | base64 -d > /data/local/tmp/vietmitv_assistant_bridge.sh && chmod 700 /data/local/tmp/vietmitv_assistant_bridge.sh"
        shell(connection, install)
        shell(connection, "sh /data/local/tmp/vietmitv_assistant_bridge.sh")
        shell(connection, "echo 'SCRIPT_LAUNCHED=1' >> $debugPath")
    }

    private fun shell(connection: AdbConnection, command: String): String {
        val stream = connection.open("shell:$command")
        val out = StringBuilder()
        return try {
            while (!stream.isClosed && out.length < 8192) {
                val bytes = stream.read()
                if (bytes.isEmpty()) break
                out.append(String(bytes, Charsets.UTF_8))
            }
            out.toString()
        } catch (_: Exception) {
            out.toString()
        } finally {
            try { stream.close() } catch (_: Exception) {}
        }
    }

    private fun loadOrCreateCrypto(): AdbCrypto {
        val dir = File(context.filesDir, "adb")
        if (!dir.exists()) dir.mkdirs()
        val privateKey = File(dir, "adbkey")
        val publicKey = File(dir, "adbkey.pub")
        return if (privateKey.exists() && publicKey.exists()) {
            AdbCrypto.loadAdbKeyPair(SelfAdbBase64, privateKey, publicKey)
        } else {
            AdbCrypto.generateAdbKeyPair(SelfAdbBase64).also {
                it.saveAdbKeyPair(privateKey, publicKey)
            }
        }
    }
}
