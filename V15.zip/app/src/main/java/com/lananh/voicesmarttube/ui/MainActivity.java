package com.lananh.voicesmarttube.ui;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.net.Uri;import android.provider.Settings;import android.view.*;import android.widget.*;import android.speech.RecognizerIntent;import com.lananh.voicesmarttube.smarttube.TargetLauncher;import java.util.ArrayList;

public class MainActivity extends Activity{
 LinearLayout root; TextView status; EditText adbHost; Spinner target;
 @Override public void onCreate(Bundle b){super.onCreate(b); build();}
 void startGoogleRecognition(){ Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"vi-VN"); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"vi-VN"); i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3); i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false); if(getPackageManager().getLaunchIntentForPackage("com.google.android.katniss")!=null)i.setPackage("com.google.android.katniss"); startActivityForResult(i,900); }
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==900){if(c==RESULT_OK&&d!=null){ArrayList<String> x=d.getStringArrayListExtra("android.speech.extra.RESULTS");if(x!=null){for(String q:x){if(q!=null&&!q.trim().isEmpty()){TargetLauncher.open(this,q.trim());break;}}}}finish();}}
 void build(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(32,32,32,32); status=new TextView(this);status.setTextColor(Color.WHITE);status.setTextSize(18);root.setBackgroundColor(Color.BLACK);root.addView(status);
  Button mic=new Button(this);mic.setText("🎙️ NÓI (Google)");mic.setOnClickListener(v->startGoogleRecognition());root.addView(mic);
  target=new Spinner(this);String[] names={"SmartTube (com.teamsmart.videomanger.tv)","YouTube TV (com.google.android.youtube.tv)"};target.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));root.addView(target);
  Button save=new Button(this);save.setText("Lưu app đích");save.setOnClickListener(v->{getSharedPreferences("cfg",0).edit().putString("target",target.getSelectedItemPosition()==0?TargetLauncher.SMARTTUBE:"com.google.android.youtube.tv").apply();status.setText("Đã lưu app đích");});root.addView(save);
  adbHost=new EditText(this);adbHost.setHint("IP TV (ADB :5555)");adbHost.setText("192.168.1.100");root.addView(adbHost);
  Button adb=new Button(this);adb.setText("Thiết lập làm Google Assistant qua ADB");adb.setOnClickListener(v->new Thread(()->{try{String host=adbHost.getText().toString().trim();String r1=com.lananh.voicesmarttube.adb.AdbExecutor.run(host,com.lananh.voicesmarttube.adb.AdbExecutor.makeAssistantCommand(getPackageName()));runOnUiThread(()->status.setText("ADB OK\nAssistant = app này\nGoogle/Katniss vẫn được giữ để nhận giọng nói."));}catch(Exception e){runOnUiThread(()->status.setText("ADB lỗi: "+e.getMessage()));}}).start());root.addView(adb);setContentView(root);}
}
