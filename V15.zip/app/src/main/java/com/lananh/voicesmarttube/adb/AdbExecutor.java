package com.lananh.voicesmarttube.adb;

import android.util.Base64;
import com.tananaev.adblib.*;
import java.net.Socket;import java.nio.charset.StandardCharsets;

public final class AdbExecutor {
 public static String run(String host,String command)throws Exception{
   Socket socket=new Socket(host,5555); socket.setSoTimeout(6000);
   AdbCrypto crypto=AdbCrypto.generateAdbKeyPair(data->Base64.encodeToString(data,Base64.NO_WRAP));
   AdbConnection conn=AdbConnection.create(socket,crypto); conn.connect();
   AdbStream stream=conn.open("shell:"+command); StringBuilder out=new StringBuilder();
   while(!stream.isClosed()){byte[] b=stream.read(); if(b!=null)out.append(new String(b,StandardCharsets.UTF_8));}
   stream.close();conn.close();socket.close();return out.toString();
 }
 public static String makeAssistantCommand(String pkg){return "settings put secure assistant "+pkg+"/.voice.VoiceInteractionService";}
 public static String keepGoogleRecognition(){return "echo Google recognition kept active";}
}
