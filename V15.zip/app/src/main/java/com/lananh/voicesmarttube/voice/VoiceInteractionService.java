package com.lananh.voicesmarttube.voice;

public class VoiceInteractionService extends android.service.voice.VoiceInteractionService {
}
