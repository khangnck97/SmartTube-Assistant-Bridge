package com.lananh.voicesmarttube.smarttube;
import android.content.*;import android.net.Uri;import android.text.TextUtils;
public final class TargetLauncher {
 public static final String SMARTTUBE="com.teamsmart.videomanger.tv";
 public static void open(Context c,String q){String p=c.getSharedPreferences("cfg",0).getString("target",SMARTTUBE); Intent i=c.getPackageManager().getLaunchIntentForPackage(p); if(i==null)return; i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); i.setAction(Intent.ACTION_VIEW); i.setData(Uri.parse("https://www.youtube.com/results?search_query="+Uri.encode(q))); i.setPackage(p); c.startActivity(i);}
}
