package com.lananh.voicesmarttube.voice;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.service.voice.VoiceInteractionSession;

import com.lananh.voicesmarttube.smarttube.TargetLauncher;

import java.util.ArrayList;

/**
 * Bridge-only voice session.
 *
 * This app deliberately has NO microphone/SpeechRecognizer engine of its own.
 * Google/Android's recognition UI is used only to turn speech into text.
 * As soon as a final result arrives, the recognition activity is considered
 * finished, the text is handed to the selected target app, and this session
 * is closed so the text cannot fall through as a normal Google Assistant
 * command.
 */
public class VoiceSession extends VoiceInteractionSession {
    private static final String GOOGLE_KATNISS = "com.google.android.katniss";
    private boolean recognitionStarted;
    private boolean resultHandled;

    public VoiceSession(android.content.Context context) {
        super(context);
    }

    @Override
    public void onShow(Bundle args, int showFlags) {
        super.onShow(args, showFlags);
        resultHandled = false;
        launchGoogleRecognition();
    }

    private void launchGoogleRecognition() {
        if (recognitionStarted || resultHandled) return;
        recognitionStarted = true;

        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "vi-VN");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Nói lệnh cho SmartTube");
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        // Use Google's TV recognizer when present. We are borrowing it only
        // for speech-to-text; the app does not implement its own voice engine.
        if (getPackageManager().getLaunchIntentForPackage(GOOGLE_KATNISS) != null) {
            i.setPackage(GOOGLE_KATNISS);
        }

        startVoiceActivity(i);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        // IMPORTANT: handle the result exactly once, then close this voice
        // session immediately. Do not leave the session alive after text is
        // obtained, otherwise Android/Google Assistant may receive the next
        // spoken command instead of our bridge.
        if (resultHandled) return;
        resultHandled = true;
        recognitionStarted = false;

        String text = null;
        if (resultCode == Activity.RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(
                    RecognizerIntent.RESULTS_RECOGNITION);
            if (results != null) {
                for (String s : results) {
                    if (s != null && !s.trim().isEmpty()) {
                        text = s.trim();
                        break;
                    }
                }
            }
        }

        // The recognition activity has returned its final result. Hand the
        // text to the selected target before ending our own voice session.
        if (text != null) {
            TargetLauncher.open(getContext(), text);
        }

        // Explicitly release the voice session immediately after handoff.
        finish();
    }

    @Override
    public void onHide() {
        recognitionStarted = false;
        super.onHide();
    }
}
