package com.lananh.voicesmarttube.voice;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.service.voice.VoiceInteractionSession;

/** Voice session that hands recognition off to a small result-proxy Activity. */
public class VoiceSession extends VoiceInteractionSession {
    private boolean started;

    public VoiceSession(Context context) {
        super(context);
    }

    @Override
    public void onShow(Bundle args, int showFlags) {
        super.onShow(args, showFlags);
        if (started) return;
        started = true;

        Intent i = new Intent(getContext(), VoiceRecognitionActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startVoiceActivity(i);
    }

    @Override
    public void onHide() {
        started = false;
        super.onHide();
    }
}
