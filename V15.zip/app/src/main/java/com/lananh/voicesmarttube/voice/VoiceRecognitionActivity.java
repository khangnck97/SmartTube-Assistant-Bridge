package com.lananh.voicesmarttube.voice;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;

import com.lananh.voicesmarttube.smarttube.TargetLauncher;

import java.util.ArrayList;

/** Transparent result proxy: Google recognition returns here, then text is handed to the target app. */
public class VoiceRecognitionActivity extends Activity {
    private static final int REQUEST_RECOGNITION = 900;
    private static final String RESULTS_RECOGNITION = "android.speech.extra.RESULTS";
    private boolean launched;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        launchRecognition();
    }

    private void launchRecognition() {
        if (launched) return;
        launched = true;

        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "vi-VN");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Nói lệnh cho SmartTube");

        if (getPackageManager().getLaunchIntentForPackage("com.google.android.katniss") != null) {
            i.setPackage("com.google.android.katniss");
        }
        startActivityForResult(i, REQUEST_RECOGNITION);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_RECOGNITION) return;

        if (resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RESULTS_RECOGNITION);
            if (results != null) {
                for (String text : results) {
                    if (text != null && !text.trim().isEmpty()) {
                        TargetLauncher.open(this, text.trim());
                        break;
                    }
                }
            }
        }
        finish();
    }
}
