package com.vietmitv.youtubevoice

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import java.net.HttpURLConnection
import java.net.URL
import java.io.BufferedReader
import java.io.InputStreamReader

class VoiceOverlayService : Service() {

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(
            77,
            Notification.Builder(this, "voice")
                .setContentTitle("YouTube Voice")
                .setContentText("Đang chờ Google Assistant")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_ASSISTANT_RESULT) {
            val query = intent.getStringExtra("assistant_query").orEmpty().trim()
            if (query.isNotEmpty()) {
                handleAssistantCommand(query)
            }
        }
        return START_STICKY
    }

    private fun handleAssistantCommand(raw: String) {
        // FIX14 behavior:
        // - "mở ..." => try to resolve ONE video ID and open that video directly.
        // - if no video ID is found, fall back to ONE search page load.
        // - anything else => ONE search page load.
        // Never loop/reload the search page.
        val isOpen = Regex("(?i)^\\s*(mở|mo)\\b").containsMatchIn(raw)
        val query = raw
            .replace(Regex("(?i)^\\s*(mở|mo|tìm kiếm|tim kiem|tìm|tim|search|youtube)\\s*"), "")
            .trim()
            .ifBlank { raw.trim() }

        if (isOpen) {
            // If Assistant already supplied a YouTube URL or bare video ID,
            // use it immediately without performing a search.
            extractVideoId(query)?.let { openYoutubeVideo(it); return }

            // Resolve the title once in background. If resolution fails,
            // open the normal YouTube search exactly once.
            Thread {
                val videoId = findFirstVideoId(query)
                Handler(Looper.getMainLooper()).post {
                    if (!videoId.isNullOrBlank()) openYoutubeVideo(videoId)
                    else openYoutubeSearch(query)
                }
            }.start()
        } else {
            openYoutubeSearch(query)
        }
    }

    private fun extractVideoId(text: String): String? {
        val patterns = listOf(
            Regex("(?i)(?:v=|youtu\\.be/|youtube\\.com/(?:watch\\?v=|shorts/|embed/))([A-Za-z0-9_-]{11})"),
            Regex("(?<![A-Za-z0-9_-])([A-Za-z0-9_-]{11})(?![A-Za-z0-9_-])")
        )
        for (p in patterns) {
            val m = p.find(text)
            if (m != null) return m.groupValues[1]
        }
        return null
    }

    private fun findFirstVideoId(query: String): String? {
        var connection: HttpURLConnection? = null
        return try {
            val url = URL("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
            connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 5000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "Mozilla/5.0 (Android) YouTubeVoice/1.0")
            }
            if (connection.responseCode !in 200..299) return null
            val body = BufferedReader(InputStreamReader(connection.inputStream, Charsets.UTF_8)).use { it.readText() }

            // YouTube search HTML contains /watch?v=VIDEO_ID entries. Pick
            // the first real 11-character ID, preserving the server's order.
            Regex("(?:\\\\/)?watch\\?v=([A-Za-z0-9_-]{11})").find(body)?.groupValues?.get(1)
                ?: Regex("(?:watch\\?v=|videoId\\\":\\\")([A-Za-z0-9_-]{11})").find(body)?.groupValues?.get(1)
        } catch (_: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }

    private fun openYoutubeVideo(videoId: String) {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val selected = prefs.getString(
            "youtube_package",
            "io.gh.reisxd.tizentube.cobalt"
        ) ?: "io.gh.reisxd.tizentube.cobalt"
        val url = "https://www.youtube.com/watch?v=$videoId"
        openYoutubeUrl(url, selected)
    }

    private fun openYoutubeSearch(query: String) {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val selected = prefs.getString(
            "youtube_package",
            "io.gh.reisxd.tizentube.cobalt"
        ) ?: "io.gh.reisxd.tizentube.cobalt"
        val url = "https://www.youtube.com/results?search_query=${Uri.encode(query)}"
        openYoutubeUrl(url, selected)
    }

    private fun openYoutubeUrl(url: String, selected: String) {
        val installed = try {
            packageManager.getApplicationInfo(selected, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }

        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (installed) setPackage(selected)
        }

        try {
            startActivity(intent)
        } catch (_: Exception) {
            // Single fallback only; do not reload/search repeatedly.
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            )
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(
                    NotificationChannel(
                        "voice",
                        "Google Assistant bridge",
                        NotificationManager.IMPORTANCE_LOW
                    )
                )
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_ASSISTANT_RESULT =
            "com.vietmitv.youtubevoice.action.HANDLE_ASSISTANT_RESULT"

        fun openSearchFromActivity(context: Context, query: String) {
            val i = Intent(context, VoiceOverlayService::class.java).apply {
                action = ACTION_ASSISTANT_RESULT
                putExtra("assistant_query", query)
            }
            context.startForegroundService(i)
        }
    }
}
