# VoiceSmartTube v0.3

Standalone Android/Android TV voice gateway. It keeps only the voice -> command -> selectable target-app flow. Default target: `com.teamsmart.videomanger.tv`.

## ADB / Google Assistant override
The app contains an optional ADB-over-TCP setup using `com.tananaev:adblib:1.3`. You must explicitly enable/authorize ADB on the TV and provide its LAN IP. The app then runs:

- `settings put secure assistant com.lananh.voicesmarttube/.voice.VoiceInteractionService`
- `am force-stop com.google.android.katniss`

ADB access is device/ROM dependent; on some Android TV builds the secure setting is restricted or the assistant role is controlled by the system UI.

The adblib project documents TCP ADB on port 5555 and the Socket -> AdbCrypto -> AdbConnection flow. See https://github.com/tananaev/adblib and Maven Central artifact `com.tananaev:adblib:1.3`.

## Build on GitHub
Use the included workflow. It installs Java 17 and Gradle 8.9 and runs `gradle assembleDebug`.


## v0.4 voice model
This version intentionally removes the app-owned `SpeechRecognizer` voice engine. Voice input is delegated to the Android/Google recognition UI (prefer `com.google.android.katniss` when present). ADB only makes VoiceSmartTube the assistant; it does **not** force-stop Katniss, because Google recognition must remain available. The selected target app is opened with the recognized query.

## Voice handoff rule (v0.5 behavior)
The app is a bridge only. It does not run its own microphone/SpeechRecognizer engine.
Google/Android recognition is used to obtain one final text result. Immediately after
that result returns, the voice session is closed and the text is handed to the selected
target (SmartTube or YouTube TV). The app does not leave Google/Katniss listening and
does not force-stop Katniss.
