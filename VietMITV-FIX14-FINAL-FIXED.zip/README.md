# VietMITV YouTube Voice Bridge - FIX14

Bám cơ chế VietMITV: Katniss -> logcat `katniss_interactor_StreamingTextView:I` -> query -> force-stop Katniss -> VoiceOverlayService.

FIX14: với câu lệnh mở video, bridge thử lấy videoId đầu tiên từ kết quả YouTube rồi mở URL `/watch?v=...` trực tiếp tới TizenTube/SmartTube. Nếu không lấy được videoId thì fallback về trang tìm kiếm.
