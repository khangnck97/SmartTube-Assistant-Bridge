# VietMITV ADB Role Bridge DEBUG 5

This build keeps Google TV Katniss as the ASSISTANT and bridges recognized voice queries into VoiceOverlayService.

Changes from DEBUG 4:
- Watches `logcat -b all` instead of only the default buffer.
- Clears all log buffers before starting.
- Keeps the original `katniss_interactor_StreamingTextView` matcher and adds `StreamingTextView` fallback.
- Uses the original VietMITV `am startservice` dispatch mechanism.
- Adds RAW / QUERY / NO_QUERY_EXTRACTED / DISPATCHED diagnostics.
- Fixes shell newline and line-continuation escaping in the embedded script.
